import { useState } from "react";

interface GenerateReplyParams {
  emailSubject: string;
  emailBody: string;
  senderName: string;
  sentiment: string;
  tone: string;
  length: string;
}

export function useGenerateReply() {
  const [loading, setLoading] = useState(false);

  const generateReply = async (params: GenerateReplyParams): Promise<string> => {
    setLoading(true);
    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const baseUrl = domain ? `https://${domain}` : "";
      const res = await fetch(`${baseUrl}/api/sentiment/reply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
      if (!res.ok) throw new Error("API error");
      const data = await res.json() as { reply: string };
      return data.reply;
    } catch {
      return generateFallbackReply(params);
    } finally {
      setLoading(false);
    }
  };

  return { generateReply, loading };
}

function generateFallbackReply(params: GenerateReplyParams): string {
  const { senderName, tone, sentiment } = params;
  const firstName = senderName.split(" ")[0];

  const openings: Record<string, string> = {
    professional: `Dear ${firstName},\n\nThank you for reaching out.`,
    friendly: `Hi ${firstName}!\n\nThanks so much for getting in touch.`,
    apologetic: `Dear ${firstName},\n\nThank you for bringing this to my attention. I sincerely apologize for any inconvenience caused.`,
    sales: `Hi ${firstName},\n\nThank you for your message — this is a great opportunity.`,
    confident: `Hi ${firstName},\n\nThank you for your message. Let me address this directly.`,
  };

  const middles: Record<string, string> = {
    positive: "I'm delighted to hear your positive feedback. It motivates our team to continue delivering exceptional work.",
    neutral: "I've reviewed your inquiry and would be happy to provide the information you need.",
    negative: "I understand your concerns and take them very seriously. I want to ensure we resolve this to your complete satisfaction.",
  };

  const closings: Record<string, string> = {
    professional: "\n\nPlease don't hesitate to reach out if you need anything further.\n\nBest regards",
    friendly: "\n\nLooking forward to hearing from you!\n\nWarm regards",
    apologetic: "\n\nI'm committed to making this right. Thank you for your patience.\n\nSincerely",
    sales: "\n\nI'd love to discuss how we can move forward together.\n\nBest regards",
    confident: "\n\nI look forward to your response.\n\nBest regards",
  };

  return `${openings[tone] || openings.professional}\n\n${middles[sentiment] || middles.neutral}${closings[tone] || closings.professional}`;
}
