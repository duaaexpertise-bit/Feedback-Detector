import { useState } from "react";

export interface FullAnalysisResult {
  sentiment: "positive" | "neutral" | "negative";
  confidence: number;
  urgency: "low" | "medium" | "high";
  indicators: string[];
  suggestedAction: string;
  shortReply: string;
  detailedReply: string;
}

export function useAnalyzePaste() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyze = async (params: {
    text: string;
    senderName?: string;
    subject?: string;
  }): Promise<FullAnalysisResult | null> => {
    setLoading(true);
    setError(null);
    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const baseUrl = domain ? `https://${domain}` : "";
      const res = await fetch(`${baseUrl}/api/sentiment/full`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
      if (!res.ok) throw new Error("API error");
      return (await res.json()) as FullAnalysisResult;
    } catch {
      return getFallbackResult(params.text);
    } finally {
      setLoading(false);
    }
  };

  return { analyze, loading, error };
}

function getFallbackResult(text: string): FullAnalysisResult {
  const lower = text.toLowerCase();
  const hasNeg = /disappoint|angry|terrible|unacceptable|urgent|refund|cancel|worst|awful|frustrated/i.test(lower);
  const hasPos = /thank|great|excellent|amazing|love|happy|satisfied|outstanding|wonderful|appreciate/i.test(lower);

  const sentiment = hasNeg ? "negative" : hasPos ? "positive" : "neutral";
  const urgency: "low" | "medium" | "high" = hasNeg ? "high" : hasPos ? "low" : "medium";

  const indicatorMap = {
    positive: [
      "Positive appreciation language detected",
      "Satisfied tone throughout the message",
      "No escalation signals present",
      "Collaborative and constructive framing",
    ],
    neutral: [
      "Informational tone — no emotional charge",
      "Standard inquiry or follow-up pattern",
      "No stress or urgency indicators",
      "Professional and objective language used",
    ],
    negative: [
      "Strong negative language or dissatisfaction detected",
      "Potential escalation risk identified",
      "Urgency signals present in message",
      "Action required to prevent further escalation",
    ],
  };

  return {
    sentiment,
    confidence: sentiment === "negative" ? 88 : sentiment === "positive" ? 85 : 76,
    urgency,
    indicators: indicatorMap[sentiment],
    suggestedAction:
      sentiment === "negative"
        ? "Respond within 1 hour to de-escalate."
        : sentiment === "positive"
        ? "Send a warm acknowledgment and explore upsell."
        : "Reply within 24 hours with requested information.",
    shortReply:
      sentiment === "negative"
        ? "Hi, thank you for reaching out — I sincerely apologize for the experience and will prioritize resolving this immediately. Please expect my follow-up within the hour."
        : sentiment === "positive"
        ? "Hi, thank you so much for your kind words — it truly means a lot to our team! We're looking forward to continuing this great collaboration."
        : "Hi, thank you for your message — I'll review the details and get back to you with a full response shortly.",
    detailedReply:
      sentiment === "negative"
        ? `Dear Client,\n\nThank you for taking the time to reach out and bring this matter to my attention. I completely understand your frustration and want you to know that your experience is not the standard we hold ourselves to.\n\nI am personally taking ownership of this issue and will investigate immediately. I will have a concrete resolution or update for you within the next hour.\n\nPlease don't hesitate to reach out directly if you need anything in the meantime. I am committed to making this right for you.\n\nBest regards`
        : sentiment === "positive"
        ? `Dear Client,\n\nThank you so much for your wonderful feedback — it truly brightens our day and motivates the entire team to keep delivering exceptional work. Hearing that you're satisfied with the results is the best outcome we could ask for.\n\nWe've thoroughly enjoyed working with you and are proud of what we've accomplished together. Your trust and support mean everything to us as we continue to grow.\n\nWe're excited about the opportunities ahead and look forward to building on this success together. Please don't hesitate to reach out anytime.\n\nWarm regards`
        : `Dear Client,\n\nThank you for your message. I've reviewed your inquiry and want to make sure I provide you with the most accurate and helpful response possible.\n\nI'll gather the relevant information and have a thorough reply ready for you shortly. If there are any additional details or documents you can share in the meantime, please feel free to send them along.\n\nThank you for your patience, and I look forward to assisting you further.\n\nBest regards`,
  };
}
