import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export type SentimentType = "positive" | "neutral" | "negative";
export type PlanType = "free" | "pro" | "enterprise";

export interface Email {
  id: string;
  sender: string;
  subject: string;
  preview: string;
  body: string;
  sentiment: SentimentType;
  confidence: number;
  time: string;
  read: boolean;
  provider: string;
  indicators: string[];
}

export interface Stats {
  total: number;
  positive: number;
  neutral: number;
  negative: number;
  positiveRatio: number;
  neutralRatio: number;
  negativeRatio: number;
  reputationScore: number;
  unread: number;
}

interface TrendDay {
  label: string;
  positive: number;
  neutral: number;
  negative: number;
}

interface User {
  name: string;
  email: string;
}

interface AppContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  emails: Email[];
  stats: Stats;
  wellbeingStreak: number;
  weeklyTrend: TrendDay[];
  monthlyTrend: TrendDay[];
  plan: PlanType;
  setPlan: (plan: PlanType) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  connectEmailProvider: (providerId: string) => void;
}

const DEMO_EMAILS: Email[] = [
  {
    id: "1",
    sender: "Sarah Johnson",
    subject: "Re: Project Delivery - Outstanding Work!",
    preview: "I just wanted to say that the final deliverable exceeded all our expectations...",
    body: "Hi,\n\nI just wanted to say that the final deliverable exceeded all our expectations. The attention to detail and the quality of work is absolutely outstanding. Our team is thrilled with the results, and we're looking forward to working together on the next phase.\n\nThank you so much for your dedication and professionalism.\n\nBest regards,\nSarah",
    sentiment: "positive",
    confidence: 97,
    time: "2m ago",
    read: false,
    provider: "Gmail",
    indicators: ["Highly positive language: 'exceeded expectations', 'outstanding'", "Strong approval signal: 'team is thrilled'", "Future engagement interest expressed", "No negative language detected"],
  },
  {
    id: "2",
    sender: "David Chen",
    subject: "URGENT: Major Issues with the Deliverable",
    preview: "I'm extremely disappointed with what we received. This is not what we agreed on...",
    body: "Hi,\n\nI'm extremely disappointed with what we received. This is not what we agreed on in our initial brief. The quality is subpar and several key features are missing. We need to have an urgent call today to discuss this. If these issues aren't resolved immediately, we may need to reconsider our partnership.\n\nDavid",
    sentiment: "negative",
    confidence: 94,
    time: "18m ago",
    read: false,
    provider: "Outlook",
    indicators: ["Strong negative language: 'extremely disappointed', 'subpar'", "Escalation threat: 'reconsider our partnership'", "Urgency signals detected: 'URGENT', 'immediately'", "Conflict indicators: expectations mismatch mentioned"],
  },
  {
    id: "3",
    sender: "Emily Rodriguez",
    subject: "Quick question about the timeline",
    preview: "Hi, could you let me know when the next milestone is due?",
    body: "Hi,\n\nCould you let me know when the next milestone is due? I need to update our internal project tracker. Also, is there anything you need from our side to keep things on track?\n\nThanks,\nEmily",
    sentiment: "neutral",
    confidence: 88,
    time: "1h ago",
    read: true,
    provider: "Gmail",
    indicators: ["Informational request — no emotional charge", "Collaborative language: 'anything you need from our side'", "Standard follow-up pattern", "No stress indicators"],
  },
  {
    id: "4",
    sender: "James Wilson",
    subject: "Invoice Dispute & Refund Request",
    preview: "We were charged incorrectly and I need a refund for the overpayment...",
    body: "Hello,\n\nWe were charged incorrectly on invoice #1042. The amount charged was $2,400 but we agreed on $1,800. I need a refund for the $600 overpayment processed immediately. This is the third billing error we've experienced and it's causing frustration on our end.\n\nPlease confirm receipt and expected resolution timeline.\n\nJames Wilson",
    sentiment: "negative",
    confidence: 91,
    time: "3h ago",
    read: false,
    provider: "Office 365",
    indicators: ["Financial dispute — refund request", "Escalation risk: 'third billing error'", "Frustration language detected", "Action demand: 'immediately'"],
  },
  {
    id: "5",
    sender: "Lisa Park",
    subject: "Partnership Opportunity",
    preview: "We'd love to explore a potential collaboration with your team...",
    body: "Hi,\n\nI came across your work and I'm genuinely impressed by your portfolio. We'd love to explore a potential collaboration. Our company specializes in enterprise SaaS and we think there's a great alignment with your services.\n\nWould you be open to a 30-minute call this week?\n\nBest,\nLisa Park",
    sentiment: "positive",
    confidence: 85,
    time: "Yesterday",
    read: true,
    provider: "Gmail",
    indicators: ["Positive opening: 'genuinely impressed'", "Opportunity signal: partnership interest", "Professional and respectful tone", "No negative indicators"],
  },
  {
    id: "6",
    sender: "Robert Kim",
    subject: "Feedback on Last Week's Meeting",
    preview: "The meeting was productive. A few notes to follow up on...",
    body: "Hi,\n\nThe meeting was productive and we covered most of the topics we needed to. A few follow-up notes:\n\n1. Can you send the updated spec by Friday?\n2. We'll need the designs reviewed before the 15th\n3. The budget discussion needs to be revisited next week\n\nLet me know if you have any questions.\n\nRobert",
    sentiment: "neutral",
    confidence: 82,
    time: "Yesterday",
    read: true,
    provider: "Outlook",
    indicators: ["Neutral meeting summary", "Action items list — task-oriented communication", "No emotional language detected", "Routine follow-up pattern"],
  },
  {
    id: "7",
    sender: "Amanda Foster",
    subject: "5-Star Review — You're Amazing!",
    preview: "Just left you a 5-star review on Google. Absolutely love the work!",
    body: "Hi!\n\nI just wanted to let you know that I left you a 5-star review on Google and also referred two of my friends to your services. The work you did for us was absolutely phenomenal. We've already seen a 40% improvement in our conversion rates since the launch.\n\nThank you so much — you're a rockstar!\n\nAmanda",
    sentiment: "positive",
    confidence: 99,
    time: "2d ago",
    read: true,
    provider: "Gmail",
    indicators: ["Exceptional positive sentiment: '5-star review'", "Referral behavior — highest trust signal", "Concrete positive outcome mentioned: 40% improvement", "Enthusiastic tone throughout"],
  },
  {
    id: "8",
    sender: "Tom Bradley",
    subject: "Clarification needed on deliverables",
    preview: "Before we proceed, I'd like to get clarity on the scope...",
    body: "Hi,\n\nBefore we proceed to the next phase, I'd like to get clarity on the exact scope of deliverables. Specifically, does the current agreement include the mobile version, or is that a separate engagement?\n\nAlso, what's the expected timeline for the QA phase?\n\nThanks,\nTom",
    sentiment: "neutral",
    confidence: 78,
    time: "2d ago",
    read: true,
    provider: "Gmail",
    indicators: ["Scope clarification request — business-routine", "No emotional indicators", "Professional questioning tone", "Information-seeking communication pattern"],
  },
];

function computeStats(emails: Email[]): Stats {
  const total = emails.length;
  const positive = emails.filter((e) => e.sentiment === "positive").length;
  const neutral = emails.filter((e) => e.sentiment === "neutral").length;
  const negative = emails.filter((e) => e.sentiment === "negative").length;
  const unread = emails.filter((e) => !e.read).length;
  const positiveRatio = total > 0 ? Math.round((positive / total) * 100) : 0;
  const neutralRatio = total > 0 ? Math.round((neutral / total) * 100) : 0;
  const negativeRatio = total > 0 ? Math.round((negative / total) * 100) : 0;
  const reputationScore = Math.min(100, Math.round(positiveRatio * 0.7 + (100 - negativeRatio) * 0.3));
  return { total, positive, neutral, negative, unread, positiveRatio, neutralRatio, negativeRatio, reputationScore };
}

const WEEKLY_TREND: TrendDay[] = [
  { label: "Mon", positive: 4, neutral: 2, negative: 1 },
  { label: "Tue", positive: 6, neutral: 3, negative: 2 },
  { label: "Wed", positive: 3, neutral: 4, negative: 3 },
  { label: "Thu", positive: 7, neutral: 2, negative: 1 },
  { label: "Fri", positive: 5, neutral: 3, negative: 2 },
  { label: "Sat", positive: 2, neutral: 1, negative: 0 },
  { label: "Sun", positive: 1, neutral: 1, negative: 1 },
];

const MONTHLY_TREND: TrendDay[] = [
  { label: "W1", positive: 18, neutral: 10, negative: 6 },
  { label: "W2", positive: 22, neutral: 12, negative: 4 },
  { label: "W3", positive: 25, neutral: 8, negative: 7 },
  { label: "W4", positive: 28, neutral: 11, negative: 3 },
];

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [emails] = useState<Email[]>(DEMO_EMAILS);
  const [plan, setPlanState] = useState<PlanType>("pro");

  useEffect(() => {
    const load = async () => {
      try {
        const [storedUser, storedPlan] = await Promise.all([
          AsyncStorage.getItem("@auth_user"),
          AsyncStorage.getItem("@selected_plan"),
        ]);
        if (storedUser) {
          setUser(JSON.parse(storedUser));
          setIsAuthenticated(true);
        }
        if (storedPlan) {
          setPlanState(storedPlan as PlanType);
        }
      } catch {}
      setIsLoading(false);
    };
    load();
  }, []);

  const setPlan = useCallback(async (newPlan: PlanType) => {
    setPlanState(newPlan);
    await AsyncStorage.setItem("@selected_plan", newPlan);
  }, []);

  const login = useCallback(async (email: string, _password: string) => {
    const u: User = {
      name: email.includes("demo") ? "Demo User" : email.split("@")[0],
      email,
    };
    await AsyncStorage.setItem("@auth_user", JSON.stringify(u));
    setUser(u);
    setIsAuthenticated(true);
  }, []);

  const logout = useCallback(() => {
    AsyncStorage.removeItem("@auth_user");
    setUser(null);
    setIsAuthenticated(false);
  }, []);

  const connectEmailProvider = useCallback((_providerId: string) => {}, []);

  const stats = computeStats(emails);

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        user,
        emails,
        stats,
        wellbeingStreak: 7,
        weeklyTrend: WEEKLY_TREND,
        monthlyTrend: MONTHLY_TREND,
        plan,
        setPlan,
        login,
        logout,
        connectEmailProvider,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppContext must be used within AppProvider");
  return ctx;
}
