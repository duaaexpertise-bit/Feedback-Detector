import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { MaterialIcons } from "@expo/vector-icons";

const SECTIONS = [
  {
    title: "1. Acceptance of Terms",
    content: `By downloading, installing, or using Feedback Detector ("the App"), you agree to be bound by these Terms of Service. If you do not agree to these terms, do not use the App.

These terms apply to all users of the App, including free and paid subscribers.`,
  },
  {
    title: "2. Description of Service",
    content: `Feedback Detector is an AI-powered email sentiment analysis tool designed to help freelancers, agencies, and business owners understand the emotional tone of client communications.

The App provides:
• Real-time sentiment classification (Positive, Neutral, Negative)
• AI-generated email reply suggestions
• Analytics and trend reporting
• Notification alerts for high-priority emails`,
  },
  {
    title: "3. User Accounts",
    content: `You are responsible for maintaining the confidentiality of your account credentials. You agree to:

• Provide accurate and complete information during sign-up
• Notify us immediately of any unauthorized access to your account
• Not share your account with others
• Not use the service for any illegal or unauthorized purpose

We reserve the right to terminate accounts that violate these terms.`,
  },
  {
    title: "4. Subscription Plans & Billing",
    content: `Feedback Detector offers the following plans:

Free Plan: Limited to 50 email analyses per month. No credit card required.

Pro Plan ($29/month): Unlimited analyses, AI Reply Assistant, advanced analytics, and priority support.

Enterprise Plan ($99/month): Everything in Pro plus team accounts, custom integrations, SLA, and dedicated support.

All paid plans are billed monthly. You may cancel at any time. Refunds are not provided for partial months.`,
  },
  {
    title: "5. Acceptable Use",
    content: `You agree not to use the App to:

• Violate any applicable laws or regulations
• Infringe on the intellectual property rights of others
• Attempt to gain unauthorized access to our systems
• Use automated tools to scrape or overload our servers
• Send spam or unsolicited communications
• Analyze emails you do not have legal permission to access`,
  },
  {
    title: "6. AI-Generated Content",
    content: `The AI Reply Assistant generates suggested email replies. These suggestions are provided as-is and are not guaranteed to be accurate, appropriate, or legally compliant for your specific situation.

You are solely responsible for reviewing, editing, and sending any AI-generated content. We are not liable for any consequences arising from the use of AI-generated replies.`,
  },
  {
    title: "7. Intellectual Property",
    content: `All content, features, and functionality of the App — including but not limited to text, graphics, logos, and software — are owned by Feedback Detector and are protected by intellectual property laws.

You may not copy, modify, distribute, or reverse engineer any part of the App without our express written permission.`,
  },
  {
    title: "8. Limitation of Liability",
    content: `To the maximum extent permitted by law, Feedback Detector shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the App.

Our total liability to you shall not exceed the amount you paid us in the 12 months preceding the claim.`,
  },
  {
    title: "9. Termination",
    content: `We may terminate or suspend your access to the App at any time, with or without cause, with or without notice. Upon termination, your right to use the App immediately ceases.

You may terminate your account at any time by contacting us at support@feedbackdetector.com.`,
  },
  {
    title: "10. Changes to Terms",
    content: `We reserve the right to modify these Terms of Service at any time. We will notify you of significant changes via in-app notification or email. Continued use of the App after changes constitutes your acceptance of the new terms.`,
  },
  {
    title: "11. Contact",
    content: `For questions about these Terms of Service, contact us at:\n\nlegal@feedbackdetector.com`,
  },
];

export default function TermsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const bottomPadding = Platform.OS === "web" ? 40 : insets.bottom + 32;

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <MaterialIcons name="arrow-back" size={22} color="#0f172a" />
        </TouchableOpacity>
        <Text style={styles.topBarTitle}>Terms of Service</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPadding }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerCard}>
          <MaterialIcons name="gavel" size={28} color="#2563EB" />
          <Text style={styles.headerTitle}>Terms of Service</Text>
          <Text style={styles.headerSub}>Last updated: June 10, 2026</Text>
          <Text style={styles.headerBody}>
            Please read these Terms of Service carefully before using Feedback Detector. By using the App, you agree to these terms.
          </Text>
        </View>

        {SECTIONS.map((section, i) => (
          <View key={i} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.content}</Text>
          </View>
        ))}

        <TouchableOpacity
          style={styles.contactBtn}
          onPress={() => Linking.openURL("mailto:legal@feedbackdetector.com")}
          activeOpacity={0.8}
        >
          <MaterialIcons name="email" size={16} color="#2563EB" />
          <Text style={styles.contactBtnText}>Contact Legal Team</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f8fafc" },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f1f5f9",
    alignItems: "center", justifyContent: "center",
  },
  topBarTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#0f172a" },
  scroll: { flex: 1 },
  headerCard: {
    backgroundColor: "#eff6ff", borderRadius: 16,
    padding: 20, marginBottom: 20,
    borderWidth: 1, borderColor: "#bfdbfe",
    alignItems: "center",
  },
  headerTitle: { fontSize: 20, fontFamily: "Inter_700Bold", color: "#0f172a", marginTop: 10, marginBottom: 4 },
  headerSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8", marginBottom: 10 },
  headerBody: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b", lineHeight: 20, textAlign: "center" },
  section: {
    backgroundColor: "#ffffff", borderRadius: 14,
    padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 10 },
  sectionBody: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 21 },
  contactBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 50, borderRadius: 14,
    backgroundColor: "#eff6ff", borderWidth: 1, borderColor: "#bfdbfe",
    marginTop: 8,
  },
  contactBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#2563EB" },
});
