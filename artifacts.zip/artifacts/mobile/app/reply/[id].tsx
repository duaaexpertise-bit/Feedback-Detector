import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAppContext } from "@/context/AppContext";
import { useGenerateReply } from "@/hooks/useGenerateReply";

type ToneType = "professional" | "friendly" | "apologetic" | "sales" | "confident";
type LengthType = "short" | "detailed";

const TONES: { key: ToneType; label: string; icon: any; desc: string }[] = [
  { key: "professional", label: "Professional", icon: "briefcase", desc: "Formal and business-appropriate" },
  { key: "friendly", label: "Friendly", icon: "smile", desc: "Warm and approachable" },
  { key: "apologetic", label: "Apologetic", icon: "heart", desc: "Empathetic and understanding" },
  { key: "sales", label: "Sales-Oriented", icon: "trending-up", desc: "Persuasive and opportunity-focused" },
  { key: "confident", label: "Confident", icon: "zap", desc: "Direct and authoritative" },
];

export default function ReplyScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { emails } = useAppContext();
  const email = emails.find((e) => e.id === id);

  const [selectedTone, setSelectedTone] = useState<ToneType>("professional");
  const [selectedLength, setSelectedLength] = useState<LengthType>("short");
  const [generatedReply, setGeneratedReply] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editedReply, setEditedReply] = useState("");

  const { generateReply, loading } = useGenerateReply();

  const bottomPadding = Platform.OS === "web" ? 34 : insets.bottom + 24;

  const handleGenerate = async () => {
    if (!email) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const reply = await generateReply({
      emailSubject: email.subject,
      emailBody: email.body,
      senderName: email.sender,
      sentiment: email.sentiment,
      tone: selectedTone,
      length: selectedLength,
    });
    setGeneratedReply(reply);
    setEditedReply(reply);
    setIsEditing(false);
  };

  const handleCopy = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  if (!email) {
    return (
      <View style={styles.notFound}>
        <Text style={styles.notFoundText}>Email not found</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPadding }}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.contextCard}>
        <View style={styles.contextHeader}>
          <Feather name="mail" size={14} color="#64748b" />
          <Text style={styles.contextLabel}>Replying to</Text>
        </View>
        <Text style={styles.contextSender}>{email.sender}</Text>
        <Text style={styles.contextSubject} numberOfLines={1}>{email.subject}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Select Tone</Text>
        <View style={styles.tonesList}>
          {TONES.map((tone) => (
            <TouchableOpacity
              key={tone.key}
              style={[styles.toneCard, selectedTone === tone.key && styles.toneCardSelected]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedTone(tone.key);
              }}
              activeOpacity={0.75}
            >
              <View style={[styles.toneIcon, selectedTone === tone.key && styles.toneIconSelected]}>
                <Feather name={tone.icon} size={16} color={selectedTone === tone.key ? "#ffffff" : "#64748b"} />
              </View>
              <View style={styles.toneInfo}>
                <Text style={[styles.toneLabel, selectedTone === tone.key && styles.toneLabelSelected]}>
                  {tone.label}
                </Text>
                <Text style={styles.toneDesc}>{tone.desc}</Text>
              </View>
              {selectedTone === tone.key && (
                <Feather name="check-circle" size={18} color="#2563EB" />
              )}
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Reply Length</Text>
        <View style={styles.lengthRow}>
          {(["short", "detailed"] as LengthType[]).map((len) => (
            <TouchableOpacity
              key={len}
              style={[styles.lengthBtn, selectedLength === len && styles.lengthBtnSelected]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedLength(len);
              }}
              activeOpacity={0.8}
            >
              <Feather
                name={len === "short" ? "align-left" : "align-justify"}
                size={16}
                color={selectedLength === len ? "#ffffff" : "#64748b"}
              />
              <Text style={[styles.lengthBtnText, selectedLength === len && styles.lengthBtnTextSelected]}>
                {len.charAt(0).toUpperCase() + len.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <TouchableOpacity style={styles.generateBtn} onPress={handleGenerate} disabled={loading} activeOpacity={0.85}>
          <LinearGradient colors={["#2563EB", "#1d4ed8"]} style={styles.generateBtnGrad}>
            {loading ? (
              <>
                <ActivityIndicator size="small" color="#ffffff" />
                <Text style={styles.generateBtnText}>Generating reply...</Text>
              </>
            ) : (
              <>
                <Feather name="cpu" size={18} color="#ffffff" />
                <Text style={styles.generateBtnText}>Generate AI Reply</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {generatedReply.length > 0 && (
        <View style={styles.section}>
          <View style={styles.replyHeader}>
            <Text style={styles.sectionTitle}>Generated Reply</Text>
            <View style={styles.replyActions}>
              <TouchableOpacity
                style={styles.iconBtn}
                onPress={() => {
                  setIsEditing(!isEditing);
                  Haptics.selectionAsync();
                }}
              >
                <Feather name={isEditing ? "check" : "edit-2"} size={16} color="#2563EB" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.iconBtn} onPress={handleCopy}>
                <Feather name="copy" size={16} color="#2563EB" />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.replyCard}>
            {isEditing ? (
              <TextInput
                style={styles.replyEditor}
                value={editedReply}
                onChangeText={setEditedReply}
                multiline
                autoFocus
                textAlignVertical="top"
              />
            ) : (
              <Text style={styles.replyText}>{editedReply || generatedReply}</Text>
            )}
          </View>

          <TouchableOpacity style={styles.sendBtn} activeOpacity={0.85} onPress={() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)}>
            <View style={styles.sendBtnInner}>
              <Feather name="send" size={18} color="#16a34a" />
              <Text style={styles.sendBtnText}>Send Reply</Text>
            </View>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8fafc" },
  notFound: { flex: 1, alignItems: "center", justifyContent: "center" },
  notFoundText: { fontSize: 16, color: "#94a3b8", fontFamily: "Inter_400Regular" },
  contextCard: {
    margin: 16, backgroundColor: "#ffffff", borderRadius: 16,
    padding: 14, borderWidth: 1, borderColor: "#e2e8f0",
  },
  contextHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 6 },
  contextLabel: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#94a3b8", textTransform: "uppercase", letterSpacing: 0.5 },
  contextSender: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#0f172a", marginBottom: 2 },
  contextSubject: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b" },
  section: { paddingHorizontal: 16, marginBottom: 16 },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 10 },
  tonesList: { gap: 8 },
  toneCard: {
    flexDirection: "row", alignItems: "center", gap: 12,
    backgroundColor: "#ffffff", borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  toneCardSelected: { borderColor: "#2563EB", backgroundColor: "#fafcff" },
  toneIcon: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f1f5f9", alignItems: "center", justifyContent: "center",
  },
  toneIconSelected: { backgroundColor: "#2563EB" },
  toneInfo: { flex: 1 },
  toneLabel: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a", marginBottom: 1 },
  toneLabelSelected: { color: "#2563EB" },
  toneDesc: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  lengthRow: { flexDirection: "row", gap: 12 },
  lengthBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 48, borderRadius: 12,
    backgroundColor: "#ffffff", borderWidth: 1, borderColor: "#e2e8f0",
  },
  lengthBtnSelected: { backgroundColor: "#2563EB", borderColor: "#2563EB" },
  lengthBtnText: { fontSize: 14, fontFamily: "Inter_500Medium", color: "#64748b" },
  lengthBtnTextSelected: { color: "#ffffff", fontFamily: "Inter_600SemiBold" },
  generateBtn: { borderRadius: 14, overflow: "hidden" },
  generateBtnGrad: {
    height: 54, flexDirection: "row",
    alignItems: "center", justifyContent: "center", gap: 10,
  },
  generateBtnText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  replyHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  replyActions: { flexDirection: "row", gap: 8 },
  iconBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#eff6ff", alignItems: "center", justifyContent: "center",
    borderWidth: 1, borderColor: "#bfdbfe",
  },
  replyCard: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
    padding: 16, marginBottom: 12,
  },
  replyText: { fontSize: 14, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 22 },
  replyEditor: {
    fontSize: 14, fontFamily: "Inter_400Regular", color: "#374151",
    lineHeight: 22, minHeight: 160,
  },
  sendBtn: {
    backgroundColor: "#f0fdf4", borderRadius: 14,
    borderWidth: 1, borderColor: "#bbf7d0", overflow: "hidden",
  },
  sendBtnInner: {
    height: 52, flexDirection: "row",
    alignItems: "center", justifyContent: "center", gap: 10,
  },
  sendBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#16a34a" },
});
