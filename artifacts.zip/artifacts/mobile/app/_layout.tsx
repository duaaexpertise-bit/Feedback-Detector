import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider } from "@/context/AppContext";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen
        name="email/[id]"
        options={{
          headerShown: true,
          headerTitle: "Email Details",
          headerBackTitle: "Back",
          headerStyle: { backgroundColor: "#ffffff" },
          headerTintColor: "#2563EB",
          presentation: "card",
        }}
      />
      <Stack.Screen
        name="reply/[id]"
        options={{
          headerShown: true,
          headerTitle: "AI Reply Assistant",
          headerBackTitle: "Back",
          headerStyle: { backgroundColor: "#ffffff" },
          headerTintColor: "#2563EB",
          presentation: "modal",
        }}
      />
      <Stack.Screen
        name="support"
        options={{ headerShown: false, presentation: "card" }}
      />
      <Stack.Screen
        name="privacy"
        options={{ headerShown: false, presentation: "card" }}
      />
      <Stack.Screen
        name="terms"
        options={{ headerShown: false, presentation: "card" }}
      />
      <Stack.Screen
        name="analyze"
        options={{ headerShown: false, presentation: "card" }}
      />
      <Stack.Screen
        name="plans"
        options={{ headerShown: false, presentation: "card" }}
      />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AppProvider>
                <RootLayoutNav />
              </AppProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
