import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Platform,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAppContext } from "@/context/AppContext";
import type { PlanType } from "@/context/AppContext";

const PLANS: {
  key: PlanType;
  name: string;
  price: string;
  period: string;
  color: string;
  gradient: [string, string];
  features: string[];
}[] = [
  {
    key: "free",
    name: "Free",
    price: "$0",
    period: "forever",
    color: "#64748b",
    gradient: ["#64748b", "#475569"],
    features: ["50 email analyses/month", "Basic sentiment detection", "Inbox view"],
  },
  {
    key: "pro",
    name: "Pro",
    price: "$29",
    period: "per month",
    color: "#2563EB",
    gradient: ["#2563EB", "#1d4ed8"],
    features: ["Unlimited email analysis", "AI Reply Assistant", "Advanced analytics", "Priority alerts", "Priority support"],
  },
  {
    key: "enterprise",
    name: "Enterprise",
    price: "$99",
    period: "per month",
    color: "#7c3aed",
    gradient: ["#7c3aed", "#6d28d9"],
    features: ["Everything in Pro", "Team accounts", "Custom integrations", "SLA guarantee", "Dedicated account manager"],
  },
];

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const { user, logout, stats, plan, setPlan } = useAppContext();

  const [pushNotifs, setPushNotifs] = useState(true);
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [autoAnalyze, setAutoAnalyze] = useState(true);
  const [negativePriority, setNegativePriority] = useState(true);
  const [switchingPlan, setSwitchingPlan] = useState<PlanType | null>(null);

  const topPadding = Platform.OS === "web" ? 67 : insets.top + 12;
  const bottomPadding = Platform.OS === "web" ? 34 : Math.max(insets.bottom, Platform.OS === "android" ? 8 : 0) + 68;

  const toggle = (setter: (v: boolean) => void, val: boolean) => {
    Haptics.selectionAsync();
    setter(!val);
  };

  const handleSelectPlan = async (newPlan: PlanType) => {
    if (newPlan === plan) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSwitchingPlan(newPlan);
    await setPlan(newPlan);
    setSwitchingPlan(null);
    const planDef = PLANS.find((p) => p.key === newPlan)!;
    Alert.alert(
      `Switched to ${planDef.name}`,
      `You're now on the ${planDef.name} plan (${planDef.price}/${planDef.period}).`,
      [{ text: "OK" }]
    );
  };

  const handleLogout = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    logout();
    router.replace("/(auth)/login");
  };

  const currentPlan = PLANS.find((p) => p.key === plan) ?? PLANS[1];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPadding }}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <Text style={styles.headerTitle}>Profile</Text>
      </View>

      <LinearGradient colors={currentPlan.gradient} style={styles.profileCard}>
        <View style={styles.avatarLarge}>
          <Text style={styles.avatarLargeText}>{user?.name?.[0] ?? "U"}</Text>
        </View>
        <Text style={styles.profileName}>{user?.name ?? "Demo User"}</Text>
        <Text style={styles.profileEmail}>{user?.email ?? "demo@feedbackdetector.com"}</Text>
        <View style={styles.planBadge}>
          <Feather name="zap" size={12} color="#fbbf24" />
          <Text style={styles.planText}>{currentPlan.name} Plan</Text>
        </View>
      </LinearGradient>

      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{stats.total}</Text>
          <Text style={styles.statLabel}>Analyzed</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{stats.positive}</Text>
          <Text style={styles.statLabel}>Positive</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{stats.reputationScore}</Text>
          <Text style={styles.statLabel}>Rep Score</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Connected Accounts</Text>
        <View style={styles.sectionCard}>
          {[
            { name: "Gmail", icon: "mail" as const, connected: true, color: "#EA4335" },
            { name: "Outlook", icon: "mail" as const, connected: false, color: "#0078d4" },
          ].map((acc, i) => (
            <View key={acc.name} style={[styles.settingRow, i > 0 && styles.settingRowBorder]}>
              <View style={[styles.settingIcon, { backgroundColor: acc.connected ? "#f0fdf4" : "#f8fafc" }]}>
                <Feather name={acc.icon} size={16} color={acc.connected ? acc.color : "#94a3b8"} />
              </View>
              <Text style={styles.settingLabel}>{acc.name}</Text>
              <View style={[styles.connBadge, { backgroundColor: acc.connected ? "#f0fdf4" : "#f8fafc", borderColor: acc.connected ? "#bbf7d0" : "#e2e8f0" }]}>
                <Text style={[styles.connText, { color: acc.connected ? "#16a34a" : "#94a3b8" }]}>
                  {acc.connected ? "Connected" : "Connect"}
                </Text>
              </View>
            </View>
          ))}
          <TouchableOpacity
            style={[styles.settingRow, styles.settingRowBorder]}
            onPress={() => router.push("/(auth)/connect")}
            activeOpacity={0.7}
          >
            <View style={[styles.settingIcon, { backgroundColor: "#eff6ff" }]}>
              <Feather name="plus" size={16} color="#2563EB" />
            </View>
            <Text style={[styles.settingLabel, { color: "#2563EB" }]}>Add Email Account</Text>
            <Feather name="chevron-right" size={16} color="#94a3b8" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notifications</Text>
        <View style={styles.sectionCard}>
          {[
            { label: "Push Notifications", value: pushNotifs, onToggle: () => toggle(setPushNotifs, pushNotifs) },
            { label: "Email Alerts", value: emailNotifs, onToggle: () => toggle(setEmailNotifs, emailNotifs) },
            { label: "Auto-Analyze New Email", value: autoAnalyze, onToggle: () => toggle(setAutoAnalyze, autoAnalyze) },
            { label: "Negative Email Priority", value: negativePriority, onToggle: () => toggle(setNegativePriority, negativePriority) },
          ].map((item, i) => (
            <View key={item.label} style={[styles.settingRow, i > 0 && styles.settingRowBorder]}>
              <Text style={styles.settingLabel}>{item.label}</Text>
              <Switch
                value={item.value}
                onValueChange={item.onToggle}
                trackColor={{ false: "#e2e8f0", true: "#bfdbfe" }}
                thumbColor={item.value ? "#2563EB" : "#94a3b8"}
              />
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.planSectionHeader}>
          <Text style={styles.sectionTitle}>Subscription Plan</Text>
          <TouchableOpacity
            style={styles.comparePlansBtn}
            onPress={() => { Haptics.selectionAsync(); router.push("/plans"); }}
            activeOpacity={0.8}
          >
            <MaterialIcons name="compare" size={13} color="#2563EB" />
            <Text style={styles.comparePlansBtnText}>Compare Plans</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.plansContainer}>
          {PLANS.map((p) => {
            const isActive = plan === p.key;
            const isSwitching = switchingPlan === p.key;
            return (
              <TouchableOpacity
                key={p.key}
                style={[
                  styles.planCard,
                  isActive && { borderColor: p.color, borderWidth: 2 },
                ]}
                onPress={() => handleSelectPlan(p.key)}
                activeOpacity={0.8}
                disabled={isSwitching}
              >
                <View style={styles.planCardHeader}>
                  <View style={styles.planCardLeft}>
                    <View style={[styles.planDot, { backgroundColor: p.color }]} />
                    <Text style={[styles.planCardName, isActive && { color: p.color }]}>{p.name}</Text>
                  </View>
                  <View style={styles.planPriceRow}>
                    <Text style={[styles.planCardPrice, isActive && { color: p.color }]}>{p.price}</Text>
                    <Text style={styles.planCardPeriod}>/{p.period === "forever" ? "free" : "mo"}</Text>
                  </View>
                </View>
                <View style={styles.planFeatureList}>
                  {p.features.map((f) => (
                    <View key={f} style={styles.planFeatureRow}>
                      <MaterialIcons
                        name="check"
                        size={14}
                        color={isActive ? p.color : "#94a3b8"}
                      />
                      <Text style={[styles.planFeatureText, isActive && { color: "#374151" }]}>{f}</Text>
                    </View>
                  ))}
                </View>
                {isActive ? (
                  <View style={[styles.activePlanBadge, { backgroundColor: p.color }]}>
                    <MaterialIcons name="check-circle" size={12} color="#ffffff" />
                    <Text style={styles.activePlanBadgeText}>Current Plan</Text>
                  </View>
                ) : (
                  <View style={[styles.switchPlanBtn, { borderColor: p.color }]}>
                    <Text style={[styles.switchPlanBtnText, { color: p.color }]}>
                      {isSwitching ? "Switching..." : `Switch to ${p.name}`}
                    </Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionCard}>
          <TouchableOpacity
            style={styles.settingRow}
            activeOpacity={0.7}
            onPress={() => { Haptics.selectionAsync(); router.push("/support"); }}
          >
            <View style={[styles.settingIcon, { backgroundColor: "#eff6ff" }]}>
              <Feather name="help-circle" size={16} color="#2563EB" />
            </View>
            <Text style={styles.settingLabel}>Help & Support</Text>
            <Feather name="chevron-right" size={16} color="#94a3b8" />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.settingRow, styles.settingRowBorder]}
            activeOpacity={0.7}
            onPress={() => { Haptics.selectionAsync(); router.push("/privacy"); }}
          >
            <View style={[styles.settingIcon, { backgroundColor: "#f8fafc" }]}>
              <Feather name="shield" size={16} color="#64748b" />
            </View>
            <Text style={styles.settingLabel}>Privacy Policy</Text>
            <Feather name="chevron-right" size={16} color="#94a3b8" />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.settingRow, styles.settingRowBorder]}
            activeOpacity={0.7}
            onPress={() => { Haptics.selectionAsync(); router.push("/terms"); }}
          >
            <View style={[styles.settingIcon, { backgroundColor: "#f8fafc" }]}>
              <Feather name="file-text" size={16} color="#64748b" />
            </View>
            <Text style={styles.settingLabel}>Terms of Service</Text>
            <Feather name="chevron-right" size={16} color="#94a3b8" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={[styles.section, { marginBottom: 8 }]}>
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.8}>
          <Feather name="log-out" size={18} color="#dc2626" />
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 8 },
  headerTitle: { fontSize: 24, fontFamily: "Inter_700Bold", color: "#0f172a" },
  profileCard: {
    marginHorizontal: 16, borderRadius: 20, padding: 24,
    alignItems: "center", marginBottom: 4,
  },
  avatarLarge: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: "rgba(255,255,255,0.25)",
    alignItems: "center", justifyContent: "center",
    marginBottom: 12, borderWidth: 2, borderColor: "rgba(255,255,255,0.4)",
  },
  avatarLargeText: { fontSize: 28, fontFamily: "Inter_700Bold", color: "#ffffff" },
  profileName: { fontSize: 20, fontFamily: "Inter_700Bold", color: "#ffffff", marginBottom: 2 },
  profileEmail: { fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)", marginBottom: 12 },
  planBadge: {
    flexDirection: "row", alignItems: "center", gap: 5,
    backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 5,
  },
  planText: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  statsRow: {
    flexDirection: "row", backgroundColor: "#ffffff",
    marginHorizontal: 16, borderRadius: 16, padding: 16,
    marginBottom: 4, borderWidth: 1, borderColor: "#e2e8f0",
  },
  statItem: { flex: 1, alignItems: "center" },
  statNum: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#2563EB", marginBottom: 2 },
  statLabel: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  statDivider: { width: 1, backgroundColor: "#e2e8f0", marginVertical: 4 },
  section: { padding: 16, paddingBottom: 4 },
  sectionTitle: {
    fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#64748b",
    marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.5,
  },
  sectionCard: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0", overflow: "hidden",
  },
  settingRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    padding: 14, backgroundColor: "#ffffff",
  },
  settingRowBorder: { borderTopWidth: 1, borderTopColor: "#f1f5f9" },
  settingIcon: {
    width: 34, height: 34, borderRadius: 10,
    alignItems: "center", justifyContent: "center",
  },
  settingLabel: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", color: "#0f172a" },
  connBadge: {
    borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4,
    borderWidth: 1,
  },
  connText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  planSectionHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8,
  },
  comparePlansBtn: {
    flexDirection: "row", alignItems: "center", gap: 4,
    backgroundColor: "#eff6ff", borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 5,
    borderWidth: 1, borderColor: "#bfdbfe",
  },
  comparePlansBtnText: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: "#2563EB" },
  plansContainer: { gap: 10 },
  planCard: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
    padding: 16,
  },
  planCardHeader: {
    flexDirection: "row", justifyContent: "space-between",
    alignItems: "center", marginBottom: 12,
  },
  planCardLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  planDot: { width: 10, height: 10, borderRadius: 5 },
  planCardName: {
    fontSize: 16, fontFamily: "Inter_700Bold", color: "#0f172a",
  },
  planPriceRow: { flexDirection: "row", alignItems: "baseline", gap: 2 },
  planCardPrice: {
    fontSize: 20, fontFamily: "Inter_700Bold", color: "#0f172a",
  },
  planCardPeriod: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  planFeatureList: { gap: 6, marginBottom: 14 },
  planFeatureRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  planFeatureText: {
    fontSize: 13, fontFamily: "Inter_400Regular", color: "#94a3b8",
  },
  activePlanBadge: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 5, height: 36, borderRadius: 10,
  },
  activePlanBadgeText: {
    fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#ffffff",
  },
  switchPlanBtn: {
    height: 36, borderRadius: 10, borderWidth: 1,
    alignItems: "center", justifyContent: "center",
  },
  switchPlanBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  logoutBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, backgroundColor: "#fef2f2", borderRadius: 14,
    padding: 16, borderWidth: 1, borderColor: "#fecaca",
  },
  logoutText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#dc2626" },
});
