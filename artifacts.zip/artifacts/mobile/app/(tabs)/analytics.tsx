import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  Dimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useAppContext } from "@/context/AppContext";

const { width } = Dimensions.get("window");
const BAR_MAX_HEIGHT = 100;

type Period = "week" | "month";

export default function AnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const { stats, weeklyTrend, monthlyTrend } = useAppContext();
  const [period, setPeriod] = useState<Period>("week");

  const topPadding = Platform.OS === "web" ? 67 : insets.top + 12;
  const bottomPadding = Platform.OS === "web" ? 34 : Math.max(insets.bottom, Platform.OS === "android" ? 8 : 0) + 68;

  const trend = period === "week" ? weeklyTrend : monthlyTrend;
  const maxVal = Math.max(...trend.flatMap((d) => [d.positive, d.neutral, d.negative]), 1);

  const METRICS = [
    { label: "Total Analyzed", value: stats.total, icon: "mail" as const, color: "#2563EB", bg: "#eff6ff" },
    { label: "Positive Rate", value: `${stats.positiveRatio}%`, icon: "thumbs-up" as const, color: "#16a34a", bg: "#f0fdf4" },
    { label: "Response Needed", value: stats.negative, icon: "alert-circle" as const, color: "#dc2626", bg: "#fef2f2" },
    { label: "Rep Score", value: `${stats.reputationScore}`, icon: "star" as const, color: "#d97706", bg: "#fffbeb" },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPadding }}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <Text style={styles.headerTitle}>Analytics</Text>
        <Text style={styles.headerSub}>Sentiment performance overview</Text>
      </View>

      <View style={styles.metricsGrid}>
        {METRICS.map((m) => (
          <View key={m.label} style={[styles.metricCard, { borderTopColor: m.color, borderTopWidth: 3 }]}>
            <View style={[styles.metricIcon, { backgroundColor: m.bg }]}>
              <Feather name={m.icon} size={16} color={m.color} />
            </View>
            <Text style={styles.metricValue}>{m.value}</Text>
            <Text style={styles.metricLabel}>{m.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Sentiment Trend</Text>
          <View style={styles.periodToggle}>
            <TouchableOpacity
              style={[styles.periodBtn, period === "week" && styles.periodBtnActive]}
              onPress={() => setPeriod("week")}
            >
              <Text style={[styles.periodText, period === "week" && styles.periodTextActive]}>Week</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodBtn, period === "month" && styles.periodBtnActive]}
              onPress={() => setPeriod("month")}
            >
              <Text style={[styles.periodText, period === "month" && styles.periodTextActive]}>Month</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.chartCard}>
          <View style={styles.chartLegend}>
            {[
              { color: "#16a34a", label: "Positive" },
              { color: "#d97706", label: "Neutral" },
              { color: "#dc2626", label: "Negative" },
            ].map((l) => (
              <View key={l.label} style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: l.color }]} />
                <Text style={styles.legendText}>{l.label}</Text>
              </View>
            ))}
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.barScroll}>
            <View style={styles.barsContainer}>
              {trend.map((d, i) => (
                <View key={i} style={styles.barGroup}>
                  <View style={styles.bars}>
                    <View style={[styles.bar, { height: (d.positive / maxVal) * BAR_MAX_HEIGHT, backgroundColor: "#16a34a" }]} />
                    <View style={[styles.bar, { height: (d.neutral / maxVal) * BAR_MAX_HEIGHT, backgroundColor: "#fbbf24" }]} />
                    <View style={[styles.bar, { height: (d.negative / maxVal) * BAR_MAX_HEIGHT, backgroundColor: "#f87171" }]} />
                  </View>
                  <Text style={styles.barLabel}>{d.label}</Text>
                </View>
              ))}
            </View>
          </ScrollView>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Reputation Monitor</Text>
        <View style={styles.repCard}>
          <LinearGradient colors={["#2563EB", "#1d4ed8"]} style={styles.repGradCard}>
            <Text style={styles.repGradLabel}>Brand Sentiment Score</Text>
            <Text style={styles.repGradScore}>{stats.reputationScore}/100</Text>
            <View style={styles.repGradBar}>
              <View style={[styles.repGradBarFill, { width: `${stats.reputationScore}%` as any }]} />
            </View>
            <Text style={styles.repGradDesc}>
              {stats.reputationScore >= 80
                ? "Excellent — Your clients love working with you"
                : "Good standing — Keep engaging positively"}
            </Text>
          </LinearGradient>

          <View style={styles.repMetrics}>
            {[
              { label: "Customer Satisfaction", value: `${stats.positiveRatio}%`, trend: "+3.2%", up: true },
              { label: "Response Rate", value: "94%", trend: "+1.1%", up: true },
              { label: "Negative Alerts", value: stats.negative.toString(), trend: "-2", up: true },
              { label: "Weekly Growth", value: "+12%", trend: "vs last week", up: true },
            ].map((m) => (
              <View key={m.label} style={styles.repMetricRow}>
                <Text style={styles.repMetricLabel}>{m.label}</Text>
                <View style={styles.repMetricRight}>
                  <Text style={styles.repMetricValue}>{m.value}</Text>
                  <View style={[styles.trendChip, { backgroundColor: m.up ? "#f0fdf4" : "#fef2f2" }]}>
                    <Feather name={m.up ? "trending-up" : "trending-down"} size={10} color={m.up ? "#16a34a" : "#dc2626"} />
                    <Text style={[styles.trendText, { color: m.up ? "#16a34a" : "#dc2626" }]}>{m.trend}</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        </View>
      </View>

      <View style={[styles.section, { marginBottom: 24 }]}>
        <Text style={styles.sectionTitle}>Mental Health Indicator</Text>
        <View style={styles.mhCard}>
          <View style={styles.mhHeader}>
            <Feather name="heart" size={20} color="#ec4899" />
            <Text style={styles.mhTitle}>Inbox Wellness Report</Text>
          </View>
          <View style={styles.mhStats}>
            <View style={styles.mhStat}>
              <Text style={styles.mhStatNum} numberOfLines={1}>{stats.positiveRatio}%</Text>
              <Text style={styles.mhStatLabel}>Positive Ratio</Text>
            </View>
            <View style={styles.mhDivider} />
            <View style={styles.mhStat}>
              <Text style={styles.mhStatNum} numberOfLines={1}>{stats.positive}</Text>
              <Text style={styles.mhStatLabel}>This Week</Text>
            </View>
            <View style={styles.mhDivider} />
            <View style={styles.mhStat}>
              <Text style={styles.mhStatNum} numberOfLines={1}>+12%</Text>
              <Text style={styles.mhStatLabel}>Growth</Text>
            </View>
          </View>
          <View style={styles.mhInsights}>
            {[
              `You received ${stats.positive} positive emails this week.`,
              "Client satisfaction is trending upward.",
              "Your response quality is improving.",
            ].map((insight, i) => (
              <View key={i} style={styles.mhInsightRow}>
                <Feather name="check-circle" size={14} color="#16a34a" />
                <Text style={styles.mhInsightText}>{insight}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  headerTitle: { fontSize: 24, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 2 },
  headerSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  metricsGrid: {
    flexDirection: "row", flexWrap: "wrap", gap: 12,
    paddingHorizontal: 16, marginBottom: 8,
  },
  metricCard: {
    width: (width - 44) / 2, backgroundColor: "#ffffff",
    borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  metricIcon: {
    width: 34, height: 34, borderRadius: 10,
    alignItems: "center", justifyContent: "center", marginBottom: 10,
  },
  metricValue: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 2 },
  metricLabel: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  section: { paddingHorizontal: 16, marginBottom: 16 },
  sectionHeaderRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  sectionTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 12 },
  periodToggle: {
    flexDirection: "row", backgroundColor: "#f1f5f9",
    borderRadius: 20, padding: 2,
  },
  periodBtn: { paddingHorizontal: 14, paddingVertical: 5, borderRadius: 18 },
  periodBtnActive: { backgroundColor: "#ffffff" },
  periodText: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#94a3b8" },
  periodTextActive: { color: "#0f172a", fontFamily: "Inter_600SemiBold" },
  chartCard: {
    backgroundColor: "#ffffff", borderRadius: 16, padding: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  chartLegend: { flexDirection: "row", gap: 16, marginBottom: 16 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#64748b" },
  barScroll: {},
  barsContainer: { flexDirection: "row", alignItems: "flex-end", gap: 8, paddingBottom: 8, minWidth: "100%" },
  barGroup: { alignItems: "center", minWidth: 36 },
  bars: { flexDirection: "row", alignItems: "flex-end", gap: 2, height: BAR_MAX_HEIGHT },
  bar: { width: 8, borderRadius: 4, minHeight: 4 },
  barLabel: { fontSize: 9, fontFamily: "Inter_400Regular", color: "#94a3b8", marginTop: 6 },
  repCard: { borderRadius: 16, overflow: "hidden", borderWidth: 1, borderColor: "#e2e8f0" },
  repGradCard: { padding: 20 },
  repGradLabel: { fontSize: 13, fontFamily: "Inter_500Medium", color: "rgba(255,255,255,0.8)", marginBottom: 4 },
  repGradScore: { fontSize: 36, fontFamily: "Inter_700Bold", color: "#ffffff", marginBottom: 12 },
  repGradBar: { height: 6, backgroundColor: "rgba(255,255,255,0.3)", borderRadius: 3, overflow: "hidden", marginBottom: 8 },
  repGradBarFill: { height: "100%", backgroundColor: "#4ade80", borderRadius: 3 },
  repGradDesc: { fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.85)" },
  repMetrics: { backgroundColor: "#ffffff" },
  repMetricRow: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: "#f1f5f9",
  },
  repMetricLabel: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b" },
  repMetricRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  repMetricValue: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a" },
  trendChip: {
    flexDirection: "row", alignItems: "center", gap: 3,
    borderRadius: 20, paddingHorizontal: 6, paddingVertical: 3,
  },
  trendText: { fontSize: 10, fontFamily: "Inter_500Medium" },
  mhCard: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0", overflow: "hidden",
  },
  mhHeader: {
    flexDirection: "row", alignItems: "center", gap: 8,
    padding: 16, borderBottomWidth: 1, borderBottomColor: "#f1f5f9",
  },
  mhTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#0f172a" },
  mhStats: { flexDirection: "row", padding: 16 },
  mhStat: { flex: 1, alignItems: "center" },
  mhStatNum: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#2563EB", marginBottom: 2 },
  mhStatLabel: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  mhDivider: { width: 1, backgroundColor: "#e2e8f0", marginVertical: 4 },
  mhInsights: { padding: 16, borderTopWidth: 1, borderTopColor: "#f1f5f9", gap: 10 },
  mhInsightRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  mhInsightText: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#374151", flex: 1 },
});
