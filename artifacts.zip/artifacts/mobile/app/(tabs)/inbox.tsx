import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useAppContext } from "@/context/AppContext";
import { SentimentBadge } from "@/components/SentimentBadge";
import type { Email } from "@/context/AppContext";

type FilterType = "all" | "positive" | "neutral" | "negative";

export default function InboxScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const { emails } = useAppContext();

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");

  const topPadding = Platform.OS === "web" ? 67 : insets.top + 12;
  const bottomPadding = Platform.OS === "web" ? 34 : Math.max(insets.bottom, Platform.OS === "android" ? 8 : 0) + 68;

  const filtered = emails.filter((e) => {
    const matchSearch =
      e.sender.toLowerCase().includes(search.toLowerCase()) ||
      e.subject.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || e.sentiment === filter;
    return matchSearch && matchFilter;
  });

  const FILTERS: { key: FilterType; label: string; color: string }[] = [
    { key: "all", label: "All", color: colors.primary },
    { key: "positive", label: "Positive", color: "#16a34a" },
    { key: "neutral", label: "Neutral", color: "#d97706" },
    { key: "negative", label: "Negative", color: "#dc2626" },
  ];

  const renderItem = ({ item }: { item: Email }) => (
    <TouchableOpacity
      style={[
        styles.emailCard,
        !item.read && styles.emailCardUnread,
      ]}
      onPress={() => router.push(`/email/${item.id}`)}
      activeOpacity={0.75}
    >
      <View style={styles.cardLeft}>
        <View style={[styles.avatar, { backgroundColor: sentimentAvatarBg(item.sentiment) }]}>
          <Text style={[styles.avatarText, { color: sentimentAvatarColor(item.sentiment) }]}>
            {item.sender[0].toUpperCase()}
          </Text>
        </View>
        {!item.read && <View style={styles.unreadDot} />}
      </View>
      <View style={styles.cardContent}>
        <View style={styles.cardTopRow}>
          <Text style={[styles.sender, !item.read && styles.senderBold]} numberOfLines={1}>
            {item.sender}
          </Text>
          <Text style={styles.time}>{item.time}</Text>
        </View>
        <Text style={styles.subject} numberOfLines={1}>{item.subject}</Text>
        <Text style={styles.preview} numberOfLines={2}>{item.preview}</Text>
        <View style={styles.cardBottomRow}>
          <SentimentBadge sentiment={item.sentiment} confidence={item.confidence} />
          <View style={styles.providerChip}>
            <Feather name="mail" size={10} color="#94a3b8" />
            <Text style={styles.providerText}>{item.provider}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <Text style={styles.headerTitle}>Inbox</Text>
        <Text style={styles.headerSub}>{filtered.length} emails analyzed</Text>
        <View style={styles.searchRow}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by sender or subject..."
            placeholderTextColor={colors.mutedForeground}
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch("")}>
              <Feather name="x" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.filterRow}>
          {FILTERS.map((f) => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterChip, filter === f.key && { backgroundColor: f.color }]}
              onPress={() => setFilter(f.key)}
              activeOpacity={0.8}
            >
              <Text style={[styles.filterText, filter === f.key && styles.filterTextActive]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPadding, gap: 10 }}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!filtered.length}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="inbox" size={40} color="#cbd5e1" />
            <Text style={styles.emptyTitle}>No emails found</Text>
            <Text style={styles.emptySub}>Try adjusting your search or filter</Text>
          </View>
        }
      />
    </View>
  );
}

function sentimentAvatarBg(s: string) {
  if (s === "positive") return "#f0fdf4";
  if (s === "negative") return "#fef2f2";
  return "#fffbeb";
}
function sentimentAvatarColor(s: string) {
  if (s === "positive") return "#16a34a";
  if (s === "negative") return "#dc2626";
  return "#d97706";
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 12, backgroundColor: "#ffffff", borderBottomWidth: 1, borderBottomColor: "#e2e8f0" },
  headerTitle: { fontSize: 24, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 2 },
  headerSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#94a3b8", marginBottom: 12 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#f8fafc", borderRadius: 12, borderWidth: 1,
    borderColor: "#e2e8f0", paddingHorizontal: 14, height: 44,
    marginBottom: 10,
  },
  searchInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", color: "#0f172a" },
  filterRow: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20,
    backgroundColor: "#f1f5f9", borderWidth: 1, borderColor: "#e2e8f0",
  },
  filterText: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#64748b" },
  filterTextActive: { color: "#ffffff" },
  emailCard: {
    flexDirection: "row", gap: 12, backgroundColor: "#ffffff",
    borderRadius: 16, padding: 14, borderWidth: 1, borderColor: "#e2e8f0",
  },
  emailCardUnread: { borderColor: "#bfdbfe", backgroundColor: "#fafcff" },
  cardLeft: { alignItems: "center", gap: 6 },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: "center", justifyContent: "center",
  },
  avatarText: { fontSize: 16, fontFamily: "Inter_700Bold" },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#2563EB" },
  cardContent: { flex: 1 },
  cardTopRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 2 },
  sender: { fontSize: 14, fontFamily: "Inter_500Medium", color: "#0f172a", flex: 1, marginRight: 8 },
  senderBold: { fontFamily: "Inter_700Bold" },
  time: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  subject: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#1e293b", marginBottom: 3 },
  preview: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8", lineHeight: 18, marginBottom: 8 },
  cardBottomRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  providerChip: { flexDirection: "row", alignItems: "center", gap: 4 },
  providerText: { fontSize: 10, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  empty: { alignItems: "center", paddingTop: 60, gap: 8 },
  emptyTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#94a3b8" },
  emptySub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#cbd5e1" },
});
