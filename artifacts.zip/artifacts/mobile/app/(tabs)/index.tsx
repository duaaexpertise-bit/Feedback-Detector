import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useAppContext } from "@/context/AppContext";
import { SentimentBadge } from "@/components/SentimentBadge";
import { MiniPieChart } from "@/components/MiniPieChart";

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const { emails, stats, wellbeingStreak } = useAppContext();

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 34 : Math.max(insets.bottom, Platform.OS === "android" ? 8 : 0) + 68;

  const recentEmails = emails.slice(0, 5);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: topPadding, paddingBottom: bottomPadding }}
      showsVerticalScrollIndicator={false}
    >
      <LinearGradient colors={["#2563EB", "#1d4ed8"]} style={styles.headerGrad}>
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.greeting}>Good morning 👋</Text>
            <Text style={styles.headerTitle}>Feedback Detector</Text>
          </View>
          <TouchableOpacity style={styles.notifBtn} onPress={() => router.push("/(tabs)/notifications")}>
            <Feather name="bell" size={20} color="#ffffff" />
            {stats.unread > 0 && (
              <View style={styles.notifDot}>
                <Text style={styles.notifDotText}>{stats.unread > 9 ? "9+" : stats.unread}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNum}>{stats.positive}</Text>
            <Text style={styles.statLabel}>Positive</Text>
            <View style={[styles.statDot, { backgroundColor: "#4ade80" }]} />
          </View>
          <View style={[styles.statCard, styles.statCardMid]}>
            <Text style={styles.statNum}>{stats.neutral}</Text>
            <Text style={styles.statLabel}>Neutral</Text>
            <View style={[styles.statDot, { backgroundColor: "#fbbf24" }]} />
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNum}>{stats.negative}</Text>
            <Text style={styles.statLabel}>Negative</Text>
            <View style={[styles.statDot, { backgroundColor: "#f87171" }]} />
          </View>
        </View>
      </LinearGradient>

      <View style={styles.body}>
        <View style={styles.row}>
          <View style={[styles.card, styles.wellbeingCard]}>
            <View style={styles.wellbeingHeader}>
              <Feather name="heart" size={18} color="#ec4899" />
              <Text style={styles.wellbeingTitle}>Wellbeing</Text>
            </View>
            <Text style={styles.wellbeingStreak}>{wellbeingStreak}</Text>
            <Text style={styles.wellbeingLabel}>day positive streak</Text>
            <Text style={styles.wellbeingInsight}>
              {stats.positiveRatio >= 70
                ? "Client satisfaction is trending upward!"
                : stats.positiveRatio >= 50
                ? "Mostly positive feedback this week."
                : "Stay focused — this will improve."}
            </Text>
          </View>

          <View style={[styles.card, styles.chartCard]}>
            <Text style={styles.cardTitle}>This Week</Text>
            <MiniPieChart
              positive={stats.positive}
              neutral={stats.neutral}
              negative={stats.negative}
            />
            <View style={styles.legendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#16a34a" }]} />
                <Text style={styles.legendText}>{stats.positiveRatio}%</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#d97706" }]} />
                <Text style={styles.legendText}>{stats.neutralRatio}%</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#dc2626" }]} />
                <Text style={styles.legendText}>{stats.negativeRatio}%</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.reputationCard}>
          <View style={styles.repHeader}>
            <View style={styles.repTitleRow}>
              <Feather name="trending-up" size={16} color="#2563EB" />
              <Text style={styles.repTitle}>Brand Reputation Score</Text>
            </View>
            <Text style={styles.repScore}>{stats.reputationScore}/100</Text>
          </View>
          <View style={styles.repBarBg}>
            <LinearGradient
              colors={["#2563EB", "#16a34a"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.repBar, { width: `${stats.reputationScore}%` as any }]}
            />
          </View>
          <Text style={styles.repSubtext}>
            {stats.reputationScore >= 80
              ? "Excellent — your clients are highly satisfied"
              : stats.reputationScore >= 60
              ? "Good — room for improvement in responsiveness"
              : "Needs attention — review negative feedback"}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.pasteCard}
          onPress={() => router.push("/analyze")}
          activeOpacity={0.88}
        >
          <LinearGradient colors={["#7c3aed", "#4f46e5"]} style={styles.pasteCardGrad}>
            <View style={styles.pasteCardLeft}>
              <View style={styles.pasteIconCircle}>
                <MaterialIcons name="content-paste" size={22} color="#7c3aed" />
              </View>
              <View style={styles.pasteCardText}>
                <View style={styles.pasteCardTitleRow}>
                  <Text style={styles.pasteCardTitle}>Paste & Analyze</Text>
                  <View style={styles.newBadge}>
                    <Text style={styles.newBadgeText}>NEW</Text>
                  </View>
                </View>
                <Text style={styles.pasteCardSub}>Paste any email → instant AI tone analysis + smart reply</Text>
              </View>
            </View>
            <MaterialIcons name="arrow-forward-ios" size={14} color="rgba(255,255,255,0.7)" />
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Emails</Text>
          <TouchableOpacity onPress={() => router.push("/(tabs)/inbox")}>
            <Text style={styles.seeAll}>See all</Text>
          </TouchableOpacity>
        </View>

        {recentEmails.map((email) => (
          <TouchableOpacity
            key={email.id}
            style={styles.emailRow}
            onPress={() => router.push(`/email/${email.id}`)}
            activeOpacity={0.7}
          >
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarText}>{email.sender[0].toUpperCase()}</Text>
            </View>
            <View style={styles.emailInfo}>
              <View style={styles.emailTopRow}>
                <Text style={styles.emailSender} numberOfLines={1}>{email.sender}</Text>
                <Text style={styles.emailTime}>{email.time}</Text>
              </View>
              <Text style={styles.emailSubject} numberOfLines={1}>{email.subject}</Text>
            </View>
            <SentimentBadge sentiment={email.sentiment} compact />
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerGrad: { padding: 20, paddingBottom: 28 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 },
  greeting: { fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)", marginBottom: 2 },
  headerTitle: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#ffffff" },
  notifBtn: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center",
  },
  notifDot: {
    position: "absolute", top: 0, right: 0,
    width: 18, height: 18, borderRadius: 9,
    backgroundColor: "#ef4444", alignItems: "center", justifyContent: "center",
    borderWidth: 1.5, borderColor: "#1d4ed8",
  },
  notifDotText: { fontSize: 9, color: "#fff", fontFamily: "Inter_700Bold" },
  statsRow: { flexDirection: "row", gap: 10 },
  statCard: {
    flex: 1, backgroundColor: "rgba(255,255,255,0.15)",
    borderRadius: 14, padding: 14, alignItems: "center",
  },
  statCardMid: {},
  statNum: { fontSize: 28, fontFamily: "Inter_700Bold", color: "#ffffff" },
  statLabel: { fontSize: 11, fontFamily: "Inter_500Medium", color: "rgba(255,255,255,0.8)", marginTop: 2 },
  statDot: { width: 6, height: 6, borderRadius: 3, marginTop: 6 },
  body: { padding: 16, gap: 14 },
  row: { flexDirection: "row", gap: 12 },
  card: {
    flex: 1, backgroundColor: "#ffffff",
    borderRadius: 16, padding: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  wellbeingCard: {},
  wellbeingHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 10 },
  wellbeingTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#0f172a" },
  wellbeingStreak: { fontSize: 36, fontFamily: "Inter_700Bold", color: "#2563EB" },
  wellbeingLabel: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8", marginBottom: 8 },
  wellbeingInsight: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#64748b", lineHeight: 16 },
  chartCard: { alignItems: "center" },
  cardTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#0f172a", marginBottom: 8, alignSelf: "flex-start" },
  legendRow: { flexDirection: "row", gap: 8, marginTop: 8 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontSize: 11, fontFamily: "Inter_500Medium", color: "#64748b" },
  reputationCard: {
    backgroundColor: "#ffffff", borderRadius: 16, padding: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  repHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  repTitleRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  repTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a" },
  repScore: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#2563EB" },
  repBarBg: { height: 8, backgroundColor: "#f1f5f9", borderRadius: 4, overflow: "hidden", marginBottom: 8 },
  repBar: { height: "100%", borderRadius: 4 },
  repSubtext: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#64748b" },
  pasteCard: { borderRadius: 16, overflow: "hidden" },
  pasteCardGrad: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    padding: 16,
  },
  pasteCardLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  pasteIconCircle: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: "#ffffff", alignItems: "center", justifyContent: "center",
    flexShrink: 0,
  },
  pasteCardText: { flex: 1 },
  pasteCardTitleRow: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 3 },
  pasteCardTitle: { fontSize: 15, fontFamily: "Inter_700Bold", color: "#ffffff" },
  newBadge: {
    backgroundColor: "#fbbf24", borderRadius: 5,
    paddingHorizontal: 5, paddingVertical: 1,
  },
  newBadgeText: { fontSize: 9, fontFamily: "Inter_700Bold", color: "#92400e" },
  pasteCardSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)", lineHeight: 16 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 4 },
  sectionTitle: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#0f172a" },
  seeAll: { fontSize: 13, fontFamily: "Inter_500Medium", color: "#2563EB" },
  emailRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    backgroundColor: "#ffffff", borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  avatarCircle: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: "#eff6ff", alignItems: "center", justifyContent: "center",
  },
  avatarText: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#2563EB" },
  emailInfo: { flex: 1 },
  emailTopRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 3 },
  emailSender: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a", flex: 1, marginRight: 8 },
  emailTime: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  emailSubject: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b" },
});
