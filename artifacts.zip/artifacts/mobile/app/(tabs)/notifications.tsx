import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";

type AlertLevel = "high" | "medium" | "low";

interface AlertItem {
  id: string;
  title: string;
  message: string;
  level: AlertLevel;
  time: string;
  read: boolean;
  sender?: string;
}

const MOCK_ALERTS: AlertItem[] = [
  { id: "1", title: "High Risk Alert", message: "Angry message from David Chen about project delays — immediate response needed.", level: "high", time: "2m ago", read: false, sender: "David Chen" },
  { id: "2", title: "Negative Sentiment Detected", message: "Sarah Miller expressed dissatisfaction with latest deliverable.", level: "medium", time: "18m ago", read: false, sender: "Sarah Miller" },
  { id: "3", title: "Refund Request", message: "Client requesting refund — escalation risk if not addressed.", level: "high", time: "1h ago", read: false, sender: "James Wilson" },
  { id: "4", title: "Complaint Received", message: "Feedback about communication delays from Emily Davis.", level: "medium", time: "3h ago", read: true, sender: "Emily Davis" },
  { id: "5", title: "Positive Streak", message: "You've received 8 positive emails this week — great work!", level: "low", time: "5h ago", read: true },
  { id: "6", title: "Weekly Report Ready", message: "Your sentiment analysis report for this week is available.", level: "low", time: "Yesterday", read: true },
  { id: "7", title: "Negative Trend Alert", message: "Negative emails up 15% this week — review your recent threads.", level: "medium", time: "Yesterday", read: true },
];

function alertColors(level: AlertLevel) {
  if (level === "high") return { bg: "#fef2f2", border: "#fecaca", icon: "#dc2626", badge: "#dc2626", badgeBg: "#fee2e2" };
  if (level === "medium") return { bg: "#fffbeb", border: "#fde68a", icon: "#d97706", badge: "#d97706", badgeBg: "#fef3c7" };
  return { bg: "#f0fdf4", border: "#bbf7d0", icon: "#16a34a", badge: "#16a34a", badgeBg: "#dcfce7" };
}

function alertIcon(level: AlertLevel) {
  if (level === "high") return "alert-octagon";
  if (level === "medium") return "alert-triangle";
  return "info";
}

export default function NotificationsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const [alerts, setAlerts] = useState<AlertItem[]>(MOCK_ALERTS);

  const topPadding = Platform.OS === "web" ? 67 : insets.top + 12;
  const bottomPadding = Platform.OS === "web" ? 34 : Math.max(insets.bottom, Platform.OS === "android" ? 8 : 0) + 68;

  const unreadCount = alerts.filter((a) => !a.read).length;

  const markAllRead = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
  };

  const markRead = (id: string) => {
    Haptics.selectionAsync();
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  const renderItem = ({ item }: { item: AlertItem }) => {
    const c = alertColors(item.level);
    const iconName = alertIcon(item.level) as any;
    return (
      <TouchableOpacity
        style={[styles.alertCard, { backgroundColor: item.read ? "#ffffff" : c.bg, borderColor: item.read ? "#e2e8f0" : c.border }]}
        onPress={() => markRead(item.id)}
        activeOpacity={0.8}
      >
        <View style={[styles.alertIcon, { backgroundColor: c.badgeBg }]}>
          <Feather name={iconName} size={18} color={c.icon} />
        </View>
        <View style={styles.alertContent}>
          <View style={styles.alertTopRow}>
            <Text style={styles.alertTitle}>{item.title}</Text>
            <Text style={styles.alertTime}>{item.time}</Text>
          </View>
          <Text style={styles.alertMessage}>{item.message}</Text>
          <View style={styles.alertBottomRow}>
            <View style={[styles.levelBadge, { backgroundColor: c.badgeBg }]}>
              <Text style={[styles.levelText, { color: c.badge }]}>
                {item.level.toUpperCase()} RISK
              </Text>
            </View>
            {!item.read && <View style={styles.unreadDot} />}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.headerTitle}>Alerts</Text>
            {unreadCount > 0 && (
              <Text style={styles.headerSub}>{unreadCount} unread alerts</Text>
            )}
          </View>
          {unreadCount > 0 && (
            <TouchableOpacity style={styles.markAllBtn} onPress={markAllRead}>
              <Feather name="check-square" size={14} color="#2563EB" />
              <Text style={styles.markAllText}>Mark all read</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.alertSummary}>
          {[
            { level: "high" as AlertLevel, count: alerts.filter((a) => a.level === "high" && !a.read).length },
            { level: "medium" as AlertLevel, count: alerts.filter((a) => a.level === "medium" && !a.read).length },
            { level: "low" as AlertLevel, count: alerts.filter((a) => a.level === "low" && !a.read).length },
          ].map((s) => {
            const c = alertColors(s.level);
            return (
              <View key={s.level} style={[styles.summaryChip, { backgroundColor: c.badgeBg, borderColor: c.border }]}>
                <View style={[styles.summaryDot, { backgroundColor: c.icon }]} />
                <Text style={[styles.summaryText, { color: c.icon }]}>
                  {s.level.charAt(0).toUpperCase() + s.level.slice(1)}: {s.count}
                </Text>
              </View>
            );
          })}
        </View>
      </View>

      <FlatList
        data={alerts}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPadding, gap: 10 }}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!alerts.length}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 16, paddingBottom: 12,
    backgroundColor: "#ffffff", borderBottomWidth: 1, borderBottomColor: "#e2e8f0",
  },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 },
  headerTitle: { fontSize: 24, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 2 },
  headerSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  markAllBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    backgroundColor: "#eff6ff", borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 7,
    borderWidth: 1, borderColor: "#bfdbfe",
  },
  markAllText: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#2563EB" },
  alertSummary: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  summaryChip: {
    flexDirection: "row", alignItems: "center", gap: 5,
    borderRadius: 20, paddingHorizontal: 10, paddingVertical: 5,
    borderWidth: 1,
  },
  summaryDot: { width: 6, height: 6, borderRadius: 3 },
  summaryText: { fontSize: 11, fontFamily: "Inter_500Medium" },
  alertCard: {
    flexDirection: "row", gap: 12, borderRadius: 16, padding: 14,
    borderWidth: 1,
  },
  alertIcon: {
    width: 44, height: 44, borderRadius: 14,
    alignItems: "center", justifyContent: "center",
    flexShrink: 0,
  },
  alertContent: { flex: 1 },
  alertTopRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  alertTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a", flex: 1, marginRight: 8 },
  alertTime: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  alertMessage: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b", lineHeight: 18, marginBottom: 8 },
  alertBottomRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  levelBadge: { borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3 },
  levelText: { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 0.5 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#2563EB" },
});
