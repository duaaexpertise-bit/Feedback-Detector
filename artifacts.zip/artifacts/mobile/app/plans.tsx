import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  Alert,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useAppContext } from "@/context/AppContext";
import type { PlanType } from "@/context/AppContext";

interface PlanDef {
  key: PlanType;
  name: string;
  price: string;
  period: string;
  tagline: string;
  recommended: boolean;
  color: string;
  gradient: [string, string];
  included: string[];
  excluded: string[];
  tooltip: string;
}

const PLANS: PlanDef[] = [
  {
    key: "free",
    name: "Free",
    price: "$0",
    period: "forever",
    tagline: "Get started with basic sentiment detection",
    recommended: false,
    color: "#64748b",
    gradient: ["#475569", "#334155"],
    included: [
      "10 analyses per month",
      "Paste & Analyze tool",
      "Basic tone detection",
      "Positive / Neutral / Negative",
      "Basic dashboard",
    ],
    excluded: [
      "AI Reply Assistant",
      "Unlimited analyses",
      "Analytics reports",
      "Export reports",
      "Priority support",
      "Team members",
      "API access",
      "CRM integrations",
    ],
    tooltip: "Perfect for freelancers just starting out who want to understand the basic tone of their client emails.",
  },
  {
    key: "pro",
    name: "Pro",
    price: "$29",
    period: "per month",
    tagline: "Everything you need to manage client relationships",
    recommended: true,
    color: "#2563EB",
    gradient: ["#2563EB", "#1d4ed8"],
    included: [
      "Unlimited analyses",
      "Unlimited Paste & Analyze",
      "AI Reply Assistant",
      "Short Reply Generator",
      "Detailed Reply Generator",
      "Analytics dashboard",
      "Sentiment history",
      "Export reports (CSV/PDF)",
      "Priority support",
    ],
    excluded: [
      "Team members",
      "API access",
      "CRM integrations",
      "White-label branding",
    ],
    tooltip: "The most popular plan for freelancers, agencies, and consultants who handle multiple client relationships daily.",
  },
  {
    key: "enterprise",
    name: "Enterprise",
    price: "$99",
    period: "per month",
    tagline: "Built for teams and agencies at scale",
    recommended: false,
    color: "#7c3aed",
    gradient: ["#7c3aed", "#6d28d9"],
    included: [
      "Everything in Pro",
      "Unlimited team members",
      "Shared team workspace",
      "Full API access",
      "CRM integrations",
      "Gmail & Outlook sync",
      "White-label branding",
      "Advanced analytics",
      "Dedicated account manager",
      "SLA guarantee (99.9%)",
      "Premium 24/7 support",
    ],
    excluded: [],
    tooltip: "Designed for agencies and larger teams who need collaboration tools, integrations, and enterprise-grade reliability.",
  },
];

const ALL_FEATURES = [
  { label: "Analyses per month", free: "10", pro: "Unlimited", ent: "Unlimited" },
  { label: "Paste & Analyze", free: true, pro: true, ent: true },
  { label: "Tone detection (Pos/Neu/Neg)", free: true, pro: true, ent: true },
  { label: "Confidence score", free: true, pro: true, ent: true },
  { label: "AI Reply Assistant", free: false, pro: true, ent: true },
  { label: "Short Reply Generator", free: false, pro: true, ent: true },
  { label: "Detailed Reply Generator", free: false, pro: true, ent: true },
  { label: "Analytics dashboard", free: false, pro: true, ent: true },
  { label: "Sentiment history", free: false, pro: true, ent: true },
  { label: "Export reports", free: false, pro: true, ent: true },
  { label: "Priority support", free: false, pro: true, ent: true },
  { label: "Team members", free: false, pro: false, ent: true },
  { label: "Shared workspace", free: false, pro: false, ent: true },
  { label: "API access", free: false, pro: false, ent: true },
  { label: "CRM integrations", free: false, pro: false, ent: true },
  { label: "Gmail/Outlook sync", free: false, pro: false, ent: true },
  { label: "White-label branding", free: false, pro: false, ent: true },
  { label: "Dedicated account manager", free: false, pro: false, ent: true },
];

function FeatureCell({ value }: { value: boolean | string }) {
  if (typeof value === "string") {
    return <Text style={styles.featureCellText}>{value}</Text>;
  }
  return (
    <MaterialIcons
      name={value ? "check-circle" : "cancel"}
      size={18}
      color={value ? "#16a34a" : "#e2e8f0"}
    />
  );
}

export default function PlansScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { plan, setPlan } = useAppContext();
  const [tooltipPlan, setTooltipPlan] = useState<PlanDef | null>(null);
  const [switching, setSwitching] = useState<PlanType | null>(null);
  const [showTable, setShowTable] = useState(false);

  const bottomPadding = Platform.OS === "web" ? 40 : insets.bottom + 32;

  const handleSelectPlan = async (p: PlanDef) => {
    if (p.key === plan) return;
    const isUpgrade =
      (plan === "free" && (p.key === "pro" || p.key === "enterprise")) ||
      (plan === "pro" && p.key === "enterprise");
    const action = isUpgrade ? "Upgrade" : "Downgrade";

    Alert.alert(
      `${action} to ${p.name}`,
      `Switch to the ${p.name} plan at ${p.price}/${p.period === "forever" ? "free" : "month"}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: action,
          style: isUpgrade ? "default" : "destructive",
          onPress: async () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            setSwitching(p.key);
            await setPlan(p.key);
            setSwitching(null);
            Alert.alert(
              `Switched to ${p.name}! 🎉`,
              `You're now on the ${p.name} plan.`,
              [{ text: "OK" }]
            );
          },
        },
      ]
    );
  };

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <MaterialIcons name="arrow-back" size={22} color="#0f172a" />
        </TouchableOpacity>
        <Text style={styles.topBarTitle}>Compare Plans</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: bottomPadding }}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient colors={["#1e40af", "#2563EB"]} style={styles.hero}>
          <MaterialIcons name="star" size={28} color="#fbbf24" />
          <Text style={styles.heroTitle}>Choose Your Plan</Text>
          <Text style={styles.heroSub}>Upgrade or downgrade at any time. No long-term contracts.</Text>
          <View style={styles.currentPlanChip}>
            <MaterialIcons name="check-circle" size={14} color="#4ade80" />
            <Text style={styles.currentPlanChipText}>
              Current plan: {PLANS.find((p) => p.key === plan)?.name ?? "Pro"}
            </Text>
          </View>
        </LinearGradient>

        <View style={styles.cardsContainer}>
          {PLANS.map((p) => {
            const isActive = plan === p.key;
            const isUpgrade =
              (plan === "free" && (p.key === "pro" || p.key === "enterprise")) ||
              (plan === "pro" && p.key === "enterprise");
            const isSwitching = switching === p.key;

            return (
              <View
                key={p.key}
                style={[
                  styles.planCard,
                  isActive && { borderColor: p.color, borderWidth: 2 },
                  p.recommended && !isActive && styles.planCardRecommended,
                ]}
              >
                {p.recommended && (
                  <View style={styles.recommendedBadge}>
                    <MaterialIcons name="auto-awesome" size={11} color="#ffffff" />
                    <Text style={styles.recommendedBadgeText}>Most Popular</Text>
                  </View>
                )}
                {isActive && (
                  <View style={[styles.activeBadge, { backgroundColor: p.color }]}>
                    <MaterialIcons name="check" size={11} color="#ffffff" />
                    <Text style={styles.activeBadgeText}>Active</Text>
                  </View>
                )}

                <LinearGradient colors={p.gradient} style={styles.planCardHeader}>
                  <Text style={styles.planCardName}>{p.name}</Text>
                  <View style={styles.planCardPriceRow}>
                    <Text style={styles.planCardPrice}>{p.price}</Text>
                    <Text style={styles.planCardPeriod}>
                      {p.period === "forever" ? "/free" : "/mo"}
                    </Text>
                  </View>
                  <Text style={styles.planCardTagline}>{p.tagline}</Text>
                </LinearGradient>

                <View style={styles.planCardBody}>
                  {p.included.map((f) => (
                    <View key={f} style={styles.featureRow}>
                      <MaterialIcons name="check-circle" size={16} color="#16a34a" />
                      <Text style={styles.featureText}>{f}</Text>
                    </View>
                  ))}
                  {p.excluded.map((f) => (
                    <View key={f} style={styles.featureRow}>
                      <MaterialIcons name="cancel" size={16} color="#e2e8f0" />
                      <Text style={styles.featureTextDisabled}>{f}</Text>
                    </View>
                  ))}
                </View>

                <View style={styles.planCardActions}>
                  <TouchableOpacity
                    style={styles.tooltipBtn}
                    onPress={() => { Haptics.selectionAsync(); setTooltipPlan(p); }}
                    activeOpacity={0.7}
                  >
                    <MaterialIcons name="info-outline" size={14} color="#64748b" />
                    <Text style={styles.tooltipBtnText}>Who is this for?</Text>
                  </TouchableOpacity>

                  {isActive ? (
                    <View style={[styles.currentPlanBtn, { backgroundColor: p.color }]}>
                      <MaterialIcons name="check-circle" size={16} color="#ffffff" />
                      <Text style={styles.currentPlanBtnText}>Current Plan</Text>
                    </View>
                  ) : (
                    <TouchableOpacity
                      style={[styles.switchBtn, { borderColor: p.color }]}
                      onPress={() => handleSelectPlan(p)}
                      disabled={isSwitching}
                      activeOpacity={0.85}
                    >
                      <Text style={[styles.switchBtnText, { color: p.color }]}>
                        {isSwitching
                          ? "Switching..."
                          : isUpgrade
                          ? `Upgrade to ${p.name}`
                          : `Downgrade to ${p.name}`}
                      </Text>
                      <MaterialIcons
                        name={isUpgrade ? "arrow-upward" : "arrow-downward"}
                        size={14}
                        color={p.color}
                      />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            );
          })}
        </View>

        <View style={styles.tableSection}>
          <TouchableOpacity
            style={styles.tableToggleBtn}
            onPress={() => { setShowTable(!showTable); Haptics.selectionAsync(); }}
            activeOpacity={0.8}
          >
            <MaterialIcons name="compare" size={18} color="#2563EB" />
            <Text style={styles.tableToggleBtnText}>
              {showTable ? "Hide" : "View"} Full Feature Comparison
            </Text>
            <MaterialIcons name={showTable ? "expand-less" : "expand-more"} size={18} color="#2563EB" />
          </TouchableOpacity>

          {showTable && (
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <View style={styles.tableFeatureCol}>
                  <Text style={styles.tableHeaderText}>Feature</Text>
                </View>
                {PLANS.map((p) => (
                  <View
                    key={p.key}
                    style={[
                      styles.tablePlanCol,
                      plan === p.key && { backgroundColor: p.color + "18" },
                    ]}
                  >
                    <Text style={[styles.tableHeaderPlan, plan === p.key && { color: p.color }]}>
                      {p.name}
                    </Text>
                    {plan === p.key && (
                      <View style={[styles.tableActiveDot, { backgroundColor: p.color }]} />
                    )}
                  </View>
                ))}
              </View>

              {ALL_FEATURES.map((feat, i) => (
                <View
                  key={feat.label}
                  style={[styles.tableRow, i % 2 === 0 && styles.tableRowAlt]}
                >
                  <View style={styles.tableFeatureCol}>
                    <Text style={styles.tableFeatureLabel}>{feat.label}</Text>
                  </View>
                  <View style={styles.tablePlanCol}>
                    <FeatureCell value={feat.free} />
                  </View>
                  <View style={styles.tablePlanCol}>
                    <FeatureCell value={feat.pro} />
                  </View>
                  <View style={styles.tablePlanCol}>
                    <FeatureCell value={feat.ent} />
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.guarantee}>
          <MaterialIcons name="verified-user" size={22} color="#16a34a" />
          <View style={styles.guaranteeText}>
            <Text style={styles.guaranteeTitle}>30-Day Money-Back Guarantee</Text>
            <Text style={styles.guaranteeSub}>Not happy? Get a full refund within 30 days, no questions asked.</Text>
          </View>
        </View>
      </ScrollView>

      <Modal
        visible={!!tooltipPlan}
        transparent
        animationType="fade"
        onRequestClose={() => setTooltipPlan(null)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setTooltipPlan(null)}
        >
          <View style={styles.tooltipModal}>
            {tooltipPlan && (
              <>
                <LinearGradient
                  colors={tooltipPlan.gradient}
                  style={styles.tooltipHeader}
                >
                  <Text style={styles.tooltipTitle}>{tooltipPlan.name} Plan</Text>
                  <Text style={styles.tooltipPrice}>{tooltipPlan.price}/{tooltipPlan.period === "forever" ? "free" : "mo"}</Text>
                </LinearGradient>
                <View style={styles.tooltipBody}>
                  <Text style={styles.tooltipLabel}>Who is this for?</Text>
                  <Text style={styles.tooltipContent}>{tooltipPlan.tooltip}</Text>
                  <TouchableOpacity
                    style={[styles.tooltipSelectBtn, { backgroundColor: tooltipPlan.color }]}
                    onPress={() => { setTooltipPlan(null); handleSelectPlan(tooltipPlan); }}
                    disabled={plan === tooltipPlan.key}
                    activeOpacity={0.85}
                  >
                    <Text style={styles.tooltipSelectBtnText}>
                      {plan === tooltipPlan.key ? "Current Plan" : `Select ${tooltipPlan.name}`}
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f8fafc" },
  topBar: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingBottom: 12,
    backgroundColor: "#ffffff", borderBottomWidth: 1, borderBottomColor: "#e2e8f0",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f1f5f9", alignItems: "center", justifyContent: "center",
  },
  topBarTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#0f172a" },
  scroll: { flex: 1 },
  hero: {
    padding: 24, paddingTop: 28, paddingBottom: 28,
    alignItems: "center",
  },
  heroTitle: { fontSize: 26, fontFamily: "Inter_700Bold", color: "#ffffff", marginTop: 8, marginBottom: 6 },
  heroSub: { fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)", textAlign: "center", marginBottom: 16 },
  currentPlanChip: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 20,
    paddingHorizontal: 14, paddingVertical: 6,
  },
  currentPlanChipText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  cardsContainer: { padding: 16, gap: 16 },
  planCard: {
    backgroundColor: "#ffffff", borderRadius: 20,
    borderWidth: 1, borderColor: "#e2e8f0",
    overflow: "hidden",
  },
  planCardRecommended: {
    borderColor: "#93c5fd", borderWidth: 1.5,
    shadowColor: "#2563EB", shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12, shadowRadius: 12, elevation: 4,
  },
  recommendedBadge: {
    position: "absolute", top: 0, right: 16, zIndex: 10,
    flexDirection: "row", alignItems: "center", gap: 4,
    backgroundColor: "#2563EB", borderBottomLeftRadius: 10, borderBottomRightRadius: 10,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  recommendedBadgeText: { fontSize: 10, fontFamily: "Inter_700Bold", color: "#ffffff" },
  activeBadge: {
    position: "absolute", top: 12, left: 12, zIndex: 10,
    flexDirection: "row", alignItems: "center", gap: 4,
    borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3,
  },
  activeBadgeText: { fontSize: 10, fontFamily: "Inter_700Bold", color: "#ffffff" },
  planCardHeader: { padding: 20, paddingTop: 28 },
  planCardName: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#ffffff", marginBottom: 4 },
  planCardPriceRow: { flexDirection: "row", alignItems: "baseline", gap: 3, marginBottom: 8 },
  planCardPrice: { fontSize: 32, fontFamily: "Inter_700Bold", color: "#ffffff" },
  planCardPeriod: { fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.75)" },
  planCardTagline: { fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.85)" },
  planCardBody: { padding: 16, gap: 8 },
  featureRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  featureText: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#374151", flex: 1 },
  featureTextDisabled: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#cbd5e1", flex: 1 },
  planCardActions: { padding: 16, paddingTop: 4, gap: 10 },
  tooltipBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    alignSelf: "flex-start",
  },
  tooltipBtnText: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#64748b" },
  currentPlanBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 6, height: 44, borderRadius: 12,
  },
  currentPlanBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  switchBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 6, height: 44, borderRadius: 12,
    borderWidth: 1.5, backgroundColor: "#ffffff",
  },
  switchBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  tableSection: { paddingHorizontal: 16, marginBottom: 16 },
  tableToggleBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 48, borderRadius: 12,
    backgroundColor: "#eff6ff", borderWidth: 1, borderColor: "#bfdbfe",
    marginBottom: 12,
  },
  tableToggleBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#2563EB" },
  table: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0", overflow: "hidden",
  },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#f8fafc",
    borderBottomWidth: 1, borderBottomColor: "#e2e8f0",
  },
  tableFeatureCol: { flex: 2, padding: 10 },
  tablePlanCol: {
    flex: 1, padding: 10,
    alignItems: "center", justifyContent: "center",
    borderLeftWidth: 1, borderLeftColor: "#f1f5f9",
  },
  tableHeaderText: { fontSize: 11, fontFamily: "Inter_700Bold", color: "#64748b", textTransform: "uppercase" },
  tableHeaderPlan: { fontSize: 12, fontFamily: "Inter_700Bold", color: "#0f172a", textAlign: "center" },
  tableActiveDot: {
    width: 5, height: 5, borderRadius: 3, marginTop: 3, alignSelf: "center",
  },
  tableRow: { flexDirection: "row" },
  tableRowAlt: { backgroundColor: "#fafafa" },
  tableFeatureLabel: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 18 },
  featureCellText: { fontSize: 11, fontFamily: "Inter_600SemiBold", color: "#0f172a", textAlign: "center" },
  guarantee: {
    flexDirection: "row", alignItems: "flex-start", gap: 12,
    marginHorizontal: 16, marginBottom: 8,
    backgroundColor: "#f0fdf4", borderRadius: 14,
    padding: 16, borderWidth: 1, borderColor: "#bbf7d0",
  },
  guaranteeText: { flex: 1 },
  guaranteeTitle: { fontSize: 14, fontFamily: "Inter_700Bold", color: "#15803d", marginBottom: 2 },
  guaranteeSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#64748b", lineHeight: 18 },
  modalOverlay: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center", justifyContent: "center",
    padding: 32,
  },
  tooltipModal: {
    backgroundColor: "#ffffff", borderRadius: 20,
    width: "100%", overflow: "hidden",
  },
  tooltipHeader: { padding: 20 },
  tooltipTitle: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#ffffff" },
  tooltipPrice: { fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)", marginTop: 2 },
  tooltipBody: { padding: 20 },
  tooltipLabel: { fontSize: 13, fontFamily: "Inter_700Bold", color: "#64748b", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 },
  tooltipContent: { fontSize: 15, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 22, marginBottom: 20 },
  tooltipSelectBtn: {
    height: 48, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
  },
  tooltipSelectBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
});
