import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { MaterialIcons } from "@expo/vector-icons";

const SECTIONS = [
  {
    title: "1. Information We Collect",
    content: `When you use Feedback Detector, we collect the following types of information:

• Account information: email address and display name you provide at sign-up.
• Email metadata: sender name, subject line, and timestamp — used solely for sentiment analysis.
• Usage data: anonymized in-app behavior to improve the product (e.g., which features you use).
• Device information: device type, OS version, and app version for debugging purposes.

We do NOT store the body of your emails on our servers. Email body content is sent to our AI provider for real-time analysis only and is not retained.`,
  },
  {
    title: "2. How We Use Your Information",
    content: `We use the information we collect to:

• Provide, maintain, and improve the Feedback Detector service.
• Analyze email sentiment in real-time using AI models.
• Send you notifications about high-risk email alerts (if enabled).
• Respond to your support requests.
• Monitor the health and performance of our services.

We will never sell your personal information to third parties.`,
  },
  {
    title: "3. Data Storage & Security",
    content: `Your email analysis data is stored locally on your device using AsyncStorage. We do not maintain a copy of your emails or analysis results on our servers.

We use industry-standard security measures including:
• Encrypted data transmission (HTTPS/TLS)
• Secure API authentication
• Regular security audits

Despite our best efforts, no method of transmission or storage is 100% secure. You use the service at your own risk.`,
  },
  {
    title: "4. Third-Party Services",
    content: `Feedback Detector uses OpenAI's API to perform sentiment analysis. When you analyze an email, the email content is temporarily sent to OpenAI for processing. OpenAI's privacy policy governs their use of this data.

We do not share your personal information with any other third parties except as required by law.`,
  },
  {
    title: "5. Your Rights",
    content: `You have the right to:

• Access the personal data we hold about you.
• Request deletion of your account and associated data.
• Opt out of usage analytics.
• Withdraw your consent at any time.

To exercise any of these rights, contact us at privacy@feedbackdetector.com.`,
  },
  {
    title: "6. Data Retention",
    content: `We retain account information for as long as your account is active. If you delete your account, we will remove your personal data from our systems within 30 days.

Email content sent for analysis is never stored on our servers and is deleted immediately after the API call completes.`,
  },
  {
    title: "7. Changes to This Policy",
    content: `We may update this Privacy Policy from time to time. We will notify you of any significant changes via in-app notification or email. Continued use of the app after changes constitutes your acceptance of the updated policy.`,
  },
  {
    title: "8. Contact Us",
    content: `If you have any questions about this Privacy Policy, please contact us at:\n\nprivacy@feedbackdetector.com`,
  },
];

export default function PrivacyScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const bottomPadding = Platform.OS === "web" ? 40 : insets.bottom + 32;

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <MaterialIcons name="arrow-back" size={22} color="#0f172a" />
        </TouchableOpacity>
        <Text style={styles.topBarTitle}>Privacy Policy</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPadding }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerCard}>
          <MaterialIcons name="privacy-tip" size={28} color="#2563EB" />
          <Text style={styles.headerTitle}>Your Privacy Matters</Text>
          <Text style={styles.headerSub}>Last updated: June 10, 2026</Text>
          <Text style={styles.headerBody}>
            This Privacy Policy explains how Feedback Detector ("we", "us", or "our") collects, uses, and protects your personal information when you use our mobile application.
          </Text>
        </View>

        {SECTIONS.map((section, i) => (
          <View key={i} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.content}</Text>
          </View>
        ))}

        <TouchableOpacity
          style={styles.contactBtn}
          onPress={() => Linking.openURL("mailto:privacy@feedbackdetector.com")}
          activeOpacity={0.8}
        >
          <MaterialIcons name="email" size={16} color="#2563EB" />
          <Text style={styles.contactBtnText}>Contact Privacy Team</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f8fafc" },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f1f5f9",
    alignItems: "center", justifyContent: "center",
  },
  topBarTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#0f172a" },
  scroll: { flex: 1 },
  headerCard: {
    backgroundColor: "#eff6ff", borderRadius: 16,
    padding: 20, marginBottom: 20,
    borderWidth: 1, borderColor: "#bfdbfe",
    alignItems: "center",
  },
  headerTitle: { fontSize: 20, fontFamily: "Inter_700Bold", color: "#0f172a", marginTop: 10, marginBottom: 4 },
  headerSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8", marginBottom: 10 },
  headerBody: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b", lineHeight: 20, textAlign: "center" },
  section: {
    backgroundColor: "#ffffff", borderRadius: 14,
    padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: "#e2e8f0",
  },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 10 },
  sectionBody: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 21 },
  contactBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 50, borderRadius: 14,
    backgroundColor: "#eff6ff", borderWidth: 1, borderColor: "#bfdbfe",
    marginTop: 8,
  },
  contactBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#2563EB" },
});
