import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Linking,
  Platform,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { MaterialIcons, Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

const FAQ_ITEMS = [
  {
    q: "How does sentiment analysis work?",
    a: "We use OpenAI's AI to analyze the tone, language patterns, and emotional indicators in your client emails. Each email is classified as Positive, Neutral, or Negative with a confidence score.",
  },
  {
    q: "Is my email data private?",
    a: "Yes. Email content is processed in real-time for analysis only. We never store the body of your emails on our servers. All data stays on your device via local storage.",
  },
  {
    q: "How do I connect my Gmail or Outlook?",
    a: "Go to Profile → Connected Accounts → Add Email Account. You can connect Gmail, Outlook, Office 365, or any IMAP account.",
  },
  {
    q: "Can I change my subscription plan?",
    a: "Yes — go to Profile → Your Plan and tap any plan to switch. Changes take effect immediately.",
  },
  {
    q: "What is the AI Reply Assistant?",
    a: "Open any email, tap 'Open AI Reply Assistant', choose a tone and length, then generate an AI-crafted reply you can edit and send.",
  },
  {
    q: "Why is my reputation score low?",
    a: "Your reputation score is calculated from the ratio of positive to negative emails. Resolve negative email threads and your score will improve over time.",
  },
];

export default function SupportScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [bugSubject, setBugSubject] = useState("");
  const [bugDesc, setBugDesc] = useState("");
  const [featureTitle, setFeatureTitle] = useState("");
  const [featureDesc, setFeatureDesc] = useState("");
  const [bugSubmitted, setBugSubmitted] = useState(false);
  const [featureSubmitted, setFeatureSubmitted] = useState(false);
  const [activeSection, setActiveSection] = useState<"faq" | "bug" | "feature">("faq");

  const bottomPadding = Platform.OS === "web" ? 40 : insets.bottom + 32;

  const submitBug = () => {
    if (!bugSubject.trim() || !bugDesc.trim()) {
      Alert.alert("Missing info", "Please fill in both subject and description.");
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setBugSubmitted(true);
    setBugSubject("");
    setBugDesc("");
    setTimeout(() => setBugSubmitted(false), 4000);
  };

  const submitFeature = () => {
    if (!featureTitle.trim() || !featureDesc.trim()) {
      Alert.alert("Missing info", "Please fill in both title and description.");
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setFeatureSubmitted(true);
    setFeatureTitle("");
    setFeatureDesc("");
    setTimeout(() => setFeatureSubmitted(false), 4000);
  };

  const toggleFaq = (i: number) => {
    Haptics.selectionAsync();
    setExpandedFaq(expandedFaq === i ? null : i);
  };

  return (
    <View style={[styles.root, { paddingTop: Platform.OS === "web" ? 0 : 0 }]}>
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <MaterialIcons name="arrow-back" size={22} color="#0f172a" />
        </TouchableOpacity>
        <Text style={styles.topBarTitle}>Help & Support</Text>
        <View style={{ width: 36 }} />
      </View>

      <View style={styles.contactBar}>
        <TouchableOpacity
          style={styles.contactChip}
          onPress={() => Linking.openURL("mailto:support@feedbackdetector.com")}
          activeOpacity={0.75}
        >
          <MaterialIcons name="email" size={16} color="#2563EB" />
          <Text style={styles.contactChipText}>support@feedbackdetector.com</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.tabRow}>
        {(["faq", "bug", "feature"] as const).map((tab) => {
          const labels = { faq: "FAQ", bug: "Report Bug", feature: "Request Feature" };
          return (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, activeSection === tab && styles.tabActive]}
              onPress={() => { Haptics.selectionAsync(); setActiveSection(tab); }}
              activeOpacity={0.8}
            >
              <Text style={[styles.tabText, activeSection === tab && styles.tabTextActive]}>
                {labels[tab]}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPadding }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {activeSection === "faq" && (
          <View style={styles.faqList}>
            {FAQ_ITEMS.map((item, i) => (
              <TouchableOpacity
                key={i}
                style={styles.faqCard}
                onPress={() => toggleFaq(i)}
                activeOpacity={0.8}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQ}>{item.q}</Text>
                  <MaterialIcons
                    name={expandedFaq === i ? "expand-less" : "expand-more"}
                    size={20}
                    color="#94a3b8"
                  />
                </View>
                {expandedFaq === i && (
                  <Text style={styles.faqA}>{item.a}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        )}

        {activeSection === "bug" && (
          <View style={styles.formCard}>
            <Text style={styles.formTitle}>Report a Bug</Text>
            <Text style={styles.formSub}>Describe the issue and we'll investigate it.</Text>

            {bugSubmitted ? (
              <View style={styles.successBox}>
                <MaterialIcons name="check-circle" size={28} color="#16a34a" />
                <Text style={styles.successTitle}>Report Submitted!</Text>
                <Text style={styles.successSub}>Thank you — we'll look into this shortly.</Text>
              </View>
            ) : (
              <>
                <Text style={styles.label}>Subject</Text>
                <TextInput
                  style={styles.input}
                  placeholder="e.g. App crashes on inbox tab"
                  placeholderTextColor="#94a3b8"
                  value={bugSubject}
                  onChangeText={setBugSubject}
                />
                <Text style={styles.label}>Description</Text>
                <TextInput
                  style={[styles.input, styles.textarea]}
                  placeholder="Describe what happened, what you expected, and steps to reproduce..."
                  placeholderTextColor="#94a3b8"
                  value={bugDesc}
                  onChangeText={setBugDesc}
                  multiline
                  textAlignVertical="top"
                />
                <TouchableOpacity style={styles.submitBtn} onPress={submitBug} activeOpacity={0.85}>
                  <MaterialIcons name="bug-report" size={18} color="#ffffff" />
                  <Text style={styles.submitBtnText}>Submit Bug Report</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        )}

        {activeSection === "feature" && (
          <View style={styles.formCard}>
            <Text style={styles.formTitle}>Request a Feature</Text>
            <Text style={styles.formSub}>Tell us what would make Feedback Detector better.</Text>

            {featureSubmitted ? (
              <View style={styles.successBox}>
                <MaterialIcons name="check-circle" size={28} color="#16a34a" />
                <Text style={styles.successTitle}>Request Submitted!</Text>
                <Text style={styles.successSub}>We review all feature requests and will consider it for our roadmap.</Text>
              </View>
            ) : (
              <>
                <Text style={styles.label}>Feature Title</Text>
                <TextInput
                  style={styles.input}
                  placeholder="e.g. Export emails as CSV"
                  placeholderTextColor="#94a3b8"
                  value={featureTitle}
                  onChangeText={setFeatureTitle}
                />
                <Text style={styles.label}>How would it help you?</Text>
                <TextInput
                  style={[styles.input, styles.textarea]}
                  placeholder="Describe the feature and how it would improve your workflow..."
                  placeholderTextColor="#94a3b8"
                  value={featureDesc}
                  onChangeText={setFeatureDesc}
                  multiline
                  textAlignVertical="top"
                />
                <TouchableOpacity style={[styles.submitBtn, { backgroundColor: "#7c3aed" }]} onPress={submitFeature} activeOpacity={0.85}>
                  <MaterialIcons name="lightbulb" size={18} color="#ffffff" />
                  <Text style={styles.submitBtnText}>Submit Feature Request</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f8fafc" },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f1f5f9",
    alignItems: "center", justifyContent: "center",
  },
  topBarTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#0f172a" },
  contactBar: {
    alignItems: "center",
    paddingVertical: 12,
    backgroundColor: "#eff6ff",
    borderBottomWidth: 1,
    borderBottomColor: "#bfdbfe",
  },
  contactChip: {
    flexDirection: "row", alignItems: "center", gap: 6,
  },
  contactChipText: { fontSize: 14, fontFamily: "Inter_500Medium", color: "#2563EB" },
  tabRow: {
    flexDirection: "row",
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  tab: {
    flex: 1, paddingVertical: 12, alignItems: "center",
    borderBottomWidth: 2, borderBottomColor: "transparent",
  },
  tabActive: { borderBottomColor: "#2563EB" },
  tabText: { fontSize: 13, fontFamily: "Inter_500Medium", color: "#94a3b8" },
  tabTextActive: { color: "#2563EB", fontFamily: "Inter_600SemiBold" },
  scroll: { flex: 1 },
  faqList: { gap: 10 },
  faqCard: {
    backgroundColor: "#ffffff", borderRadius: 14,
    padding: 16, borderWidth: 1, borderColor: "#e2e8f0",
  },
  faqHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 10 },
  faqQ: { flex: 1, fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a", lineHeight: 20 },
  faqA: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b", lineHeight: 20, marginTop: 10 },
  formCard: {
    backgroundColor: "#ffffff", borderRadius: 16,
    padding: 20, borderWidth: 1, borderColor: "#e2e8f0",
  },
  formTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#0f172a", marginBottom: 4 },
  formSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#94a3b8", marginBottom: 20 },
  label: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#374151", marginBottom: 6, marginTop: 12 },
  input: {
    backgroundColor: "#f8fafc", borderRadius: 12,
    borderWidth: 1, borderColor: "#e2e8f0",
    paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 14, fontFamily: "Inter_400Regular", color: "#0f172a",
  },
  textarea: { minHeight: 120, paddingTop: 12 },
  submitBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 52, borderRadius: 14,
    backgroundColor: "#2563EB", marginTop: 20,
  },
  submitBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  successBox: {
    alignItems: "center", paddingVertical: 24, gap: 8,
  },
  successTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#16a34a" },
  successSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b", textAlign: "center" },
});
