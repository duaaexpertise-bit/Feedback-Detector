import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useAppContext } from "@/context/AppContext";

const EMAIL_PROVIDERS = [
  {
    id: "gmail",
    name: "Gmail",
    subtitle: "Connect your Google account",
    icon: "mail" as const,
    color: "#EA4335",
    bg: "#fef2f2",
  },
  {
    id: "outlook",
    name: "Outlook",
    subtitle: "Connect your Microsoft account",
    icon: "mail" as const,
    color: "#0078d4",
    bg: "#eff6ff",
  },
  {
    id: "office365",
    name: "Microsoft 365",
    subtitle: "Work & business accounts",
    icon: "briefcase" as const,
    color: "#d83b01",
    bg: "#fff7ed",
  },
  {
    id: "imap",
    name: "IMAP / Other",
    subtitle: "Any email provider",
    icon: "server" as const,
    color: "#7c3aed",
    bg: "#f5f3ff",
  },
];

export default function ConnectScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { connectEmailProvider } = useAppContext();
  const [connecting, setConnecting] = useState<string | null>(null);
  const [connected, setConnected] = useState<string[]>([]);

  const handleConnect = async (providerId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setConnecting(providerId);
    await new Promise((r) => setTimeout(r, 1200));
    setConnected((prev) => [...prev, providerId]);
    connectEmailProvider(providerId);
    setConnecting(null);
  };

  const handleContinue = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.replace("/(tabs)");
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <LinearGradient colors={["#2563EB", "#1d4ed8"]} style={styles.headerGrad}>
        <View style={styles.headerContent}>
          <View style={styles.stepBadge}>
            <Text style={styles.stepText}>Step 2 of 2</Text>
          </View>
          <Text style={styles.headerTitle}>Connect Your Email</Text>
          <Text style={styles.headerSub}>
            Choose your email provider to start analyzing sentiment
          </Text>
        </View>
      </LinearGradient>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.providers}>
          {EMAIL_PROVIDERS.map((p) => {
            const isConnected = connected.includes(p.id);
            const isConnecting = connecting === p.id;
            return (
              <TouchableOpacity
                key={p.id}
                style={[styles.providerCard, isConnected && styles.providerCardConnected]}
                onPress={() => !isConnected && handleConnect(p.id)}
                activeOpacity={isConnected ? 1 : 0.8}
              >
                <View style={[styles.providerIcon, { backgroundColor: p.bg }]}>
                  <Feather name={p.icon} size={22} color={p.color} />
                </View>
                <View style={styles.providerInfo}>
                  <Text style={styles.providerName}>{p.name}</Text>
                  <Text style={styles.providerSub}>{p.subtitle}</Text>
                </View>
                <View style={styles.providerAction}>
                  {isConnected ? (
                    <View style={styles.connectedBadge}>
                      <Feather name="check" size={14} color="#16a34a" />
                      <Text style={styles.connectedText}>Connected</Text>
                    </View>
                  ) : isConnecting ? (
                    <Text style={styles.connectingText}>Connecting...</Text>
                  ) : (
                    <View style={styles.connectBtn}>
                      <Text style={styles.connectBtnText}>Connect</Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.securityNote}>
          <Feather name="shield" size={14} color="#2563EB" />
          <Text style={styles.securityText}>
            We only read email metadata. Your email content is processed securely and never stored.
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.continueBtn,
            connected.length === 0 && styles.continueBtnDisabled,
          ]}
          onPress={handleContinue}
          activeOpacity={0.85}
          disabled={connected.length === 0}
        >
          <LinearGradient
            colors={connected.length > 0 ? ["#2563EB", "#1d4ed8"] : ["#94a3b8", "#94a3b8"]}
            style={styles.continueBtnGrad}
          >
            <Text style={styles.continueBtnText}>
              {connected.length > 0 ? "Start Analyzing" : "Connect at least one account"}
            </Text>
            {connected.length > 0 && <Feather name="arrow-right" size={18} color="#fff" />}
          </LinearGradient>
        </TouchableOpacity>

        <TouchableOpacity onPress={handleContinue} style={styles.skipBtn}>
          <Text style={styles.skipText}>Skip for now</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8fafc" },
  headerGrad: { paddingHorizontal: 24, paddingTop: 16, paddingBottom: 32 },
  headerContent: { alignItems: "center" },
  stepBadge: {
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 4,
    marginBottom: 12,
  },
  stepText: { color: "#ffffff", fontSize: 12, fontFamily: "Inter_500Medium" },
  headerTitle: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    color: "#ffffff",
    marginBottom: 8,
    textAlign: "center",
  },
  headerSub: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.85)",
    textAlign: "center",
  },
  content: { padding: 20 },
  providers: { gap: 12, marginBottom: 20 },
  providerCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#ffffff",
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    gap: 14,
  },
  providerCardConnected: {
    borderColor: "#bbf7d0",
    backgroundColor: "#f0fdf4",
  },
  providerIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  providerInfo: { flex: 1 },
  providerName: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#0f172a" },
  providerSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "#94a3b8", marginTop: 2 },
  providerAction: {},
  connectedBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "#f0fdf4",
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: "#bbf7d0",
  },
  connectedText: { fontSize: 12, color: "#16a34a", fontFamily: "Inter_600SemiBold" },
  connectingText: { fontSize: 12, color: "#2563EB", fontFamily: "Inter_500Medium" },
  connectBtn: {
    backgroundColor: "#eff6ff",
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "#bfdbfe",
  },
  connectBtnText: { fontSize: 12, color: "#2563EB", fontFamily: "Inter_600SemiBold" },
  securityNote: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    backgroundColor: "#eff6ff",
    borderRadius: 12,
    padding: 14,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#bfdbfe",
  },
  securityText: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular", color: "#1d4ed8", lineHeight: 18 },
  continueBtn: { borderRadius: 14, overflow: "hidden", marginBottom: 12 },
  continueBtnDisabled: {},
  continueBtnGrad: {
    height: 54,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  continueBtnText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  skipBtn: { alignItems: "center", paddingVertical: 12 },
  skipText: { fontSize: 14, fontFamily: "Inter_400Regular", color: "#94a3b8" },
});
