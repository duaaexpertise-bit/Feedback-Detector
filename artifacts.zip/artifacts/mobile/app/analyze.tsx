import React, { useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Platform,
  Alert,
  Animated,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { MaterialIcons, Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import * as Clipboard from "expo-clipboard";
import { useAnalyzePaste } from "@/hooks/useAnalyzePaste";
import type { FullAnalysisResult } from "@/hooks/useAnalyzePaste";

const SENTIMENT_CONFIG = {
  positive: {
    gradient: ["#16a34a", "#15803d"] as [string, string],
    bg: "#f0fdf4",
    border: "#bbf7d0",
    text: "#15803d",
    label: "Positive Tone",
    icon: "sentiment-very-satisfied" as const,
    badgeBg: "#dcfce7",
  },
  neutral: {
    gradient: ["#d97706", "#b45309"] as [string, string],
    bg: "#fffbeb",
    border: "#fde68a",
    text: "#b45309",
    label: "Neutral Tone",
    icon: "sentiment-neutral" as const,
    badgeBg: "#fef3c7",
  },
  negative: {
    gradient: ["#dc2626", "#b91c1c"] as [string, string],
    bg: "#fef2f2",
    border: "#fecaca",
    text: "#b91c1c",
    label: "Negative Tone",
    icon: "sentiment-very-dissatisfied" as const,
    badgeBg: "#fee2e2",
  },
};

const URGENCY_CONFIG = {
  low: { color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0", label: "Low Urgency" },
  medium: { color: "#d97706", bg: "#fffbeb", border: "#fde68a", label: "Medium Urgency" },
  high: { color: "#dc2626", bg: "#fef2f2", border: "#fecaca", label: "High Urgency" },
};

const EXAMPLE_TEXTS = [
  "I'm extremely disappointed with the work delivered. This is completely unacceptable and I need this resolved immediately or I'll have to reconsider our partnership.",
  "Hi! I just wanted to say the project turned out absolutely amazing. The team exceeded all expectations — truly outstanding work!",
  "Could you let me know the timeline for the next deliverable? We need to update our internal planning before the end of the month.",
];

export default function AnalyzeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { analyze, loading } = useAnalyzePaste();
  const scrollRef = useRef<ScrollView>(null);

  const [text, setText] = useState("");
  const [senderName, setSenderName] = useState("");
  const [subject, setSubject] = useState("");
  const [result, setResult] = useState<FullAnalysisResult | null>(null);
  const [copiedShort, setCopiedShort] = useState(false);
  const [copiedDetailed, setCopiedDetailed] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [activeReplyTab, setActiveReplyTab] = useState<"short" | "detailed">("short");

  const bottomPadding = Platform.OS === "web" ? 40 : insets.bottom + 32;

  const handleAnalyze = async () => {
    if (!text.trim() || text.trim().length < 10) {
      Alert.alert("Too short", "Please paste at least a sentence to analyze.");
      return;
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const r = await analyze({ text, senderName: senderName || undefined, subject: subject || undefined });
    if (r) {
      setResult(r);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(() => scrollRef.current?.scrollTo({ y: 420, animated: true }), 200);
    }
  };

  const handleCopy = async (content: string, which: "short" | "detailed") => {
    await Clipboard.setStringAsync(content);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    if (which === "short") { setCopiedShort(true); setTimeout(() => setCopiedShort(false), 2000); }
    else { setCopiedDetailed(true); setTimeout(() => setCopiedDetailed(false), 2000); }
  };

  const handleClear = () => {
    Haptics.selectionAsync();
    setText("");
    setSenderName("");
    setSubject("");
    setResult(null);
    setShowAdvanced(false);
  };

  const loadExample = (i: number) => {
    setText(EXAMPLE_TEXTS[i]);
    setResult(null);
    Haptics.selectionAsync();
  };

  const cfg = result ? SENTIMENT_CONFIG[result.sentiment] : null;
  const urgCfg = result ? URGENCY_CONFIG[result.urgency] : null;

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <MaterialIcons name="arrow-back" size={22} color="#0f172a" />
        </TouchableOpacity>
        <View style={styles.topBarCenter}>
          <Text style={styles.topBarTitle}>Paste & Analyze</Text>
          <View style={styles.aiBadge}>
            <MaterialIcons name="auto-awesome" size={10} color="#7c3aed" />
            <Text style={styles.aiBadgeText}>AI Powered</Text>
          </View>
        </View>
        {result ? (
          <TouchableOpacity onPress={handleClear} style={styles.clearBtn} activeOpacity={0.7}>
            <Text style={styles.clearBtnText}>Clear</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ width: 44 }} />
        )}
      </View>

      <ScrollView
        ref={scrollRef}
        style={styles.scroll}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPadding }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.inputCard}>
          <View style={styles.inputCardHeader}>
            <MaterialIcons name="content-paste" size={18} color="#2563EB" />
            <Text style={styles.inputCardTitle}>Paste your email or message</Text>
          </View>

          <TextInput
            style={styles.textArea}
            placeholder="Paste any client email, message, review, or feedback here..."
            placeholderTextColor="#94a3b8"
            value={text}
            onChangeText={setText}
            multiline
            textAlignVertical="top"
            autoCorrect={false}
          />

          <View style={styles.charCount}>
            <Text style={[styles.charCountText, text.length > 1500 && { color: "#d97706" }]}>
              {text.length} characters
            </Text>
            {text.length > 0 && (
              <TouchableOpacity onPress={() => setText("")} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <MaterialIcons name="close" size={16} color="#94a3b8" />
              </TouchableOpacity>
            )}
          </View>

          <TouchableOpacity
            style={styles.advancedToggle}
            onPress={() => setShowAdvanced(!showAdvanced)}
            activeOpacity={0.7}
          >
            <Text style={styles.advancedToggleText}>
              {showAdvanced ? "Hide" : "Add"} sender / subject (optional)
            </Text>
            <MaterialIcons name={showAdvanced ? "expand-less" : "expand-more"} size={18} color="#64748b" />
          </TouchableOpacity>

          {showAdvanced && (
            <View style={styles.advancedFields}>
              <TextInput
                style={styles.advancedInput}
                placeholder="Sender name (e.g. Sarah Johnson)"
                placeholderTextColor="#94a3b8"
                value={senderName}
                onChangeText={setSenderName}
              />
              <TextInput
                style={styles.advancedInput}
                placeholder="Subject line (e.g. Re: Invoice #1042)"
                placeholderTextColor="#94a3b8"
                value={subject}
                onChangeText={setSubject}
              />
            </View>
          )}
        </View>

        <View style={styles.exampleRow}>
          <Text style={styles.exampleLabel}>Try an example:</Text>
          <View style={styles.exampleChips}>
            {["Angry client", "Happy client", "Neutral inquiry"].map((label, i) => (
              <TouchableOpacity
                key={label}
                style={[
                  styles.exampleChip,
                  i === 0 && styles.exampleChipRed,
                  i === 1 && styles.exampleChipGreen,
                ]}
                onPress={() => loadExample(i)}
                activeOpacity={0.75}
              >
                <Text style={[
                  styles.exampleChipText,
                  i === 0 && { color: "#dc2626" },
                  i === 1 && { color: "#16a34a" },
                ]}>
                  {label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <TouchableOpacity
          style={[styles.analyzeBtn, (!text.trim() || loading) && styles.analyzeBtnDisabled]}
          onPress={handleAnalyze}
          disabled={!text.trim() || loading}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={loading ? ["#93c5fd", "#60a5fa"] : ["#2563EB", "#1d4ed8"]}
            style={styles.analyzeBtnGrad}
          >
            {loading ? (
              <>
                <MaterialIcons name="auto-awesome" size={20} color="#ffffff" />
                <Text style={styles.analyzeBtnText}>Analyzing with AI...</Text>
              </>
            ) : (
              <>
                <MaterialIcons name="psychology" size={20} color="#ffffff" />
                <Text style={styles.analyzeBtnText}>Analyze Tone</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        {result && cfg && urgCfg && (
          <>
            <LinearGradient colors={cfg.gradient} style={styles.resultBanner}>
              <View style={styles.resultBannerTop}>
                <View style={styles.resultBannerLeft}>
                  <MaterialIcons name={cfg.icon} size={32} color="#ffffff" />
                  <View>
                    <Text style={styles.resultSentimentLabel}>{cfg.label}</Text>
                    <Text style={styles.resultSentimentSub}>AI Classification</Text>
                  </View>
                </View>
                <View style={styles.confidenceCircle}>
                  <Text style={styles.confidenceNum}>{result.confidence}%</Text>
                  <Text style={styles.confidenceSub}>confidence</Text>
                </View>
              </View>
              <View style={styles.confidenceBarBg}>
                <View style={[styles.confidenceBarFill, { width: `${result.confidence}%` as any }]} />
              </View>
            </LinearGradient>

            <View style={styles.metaRow}>
              <View style={[styles.metaBadge, { backgroundColor: urgCfg.bg, borderColor: urgCfg.border }]}>
                <MaterialIcons name="bolt" size={14} color={urgCfg.color} />
                <Text style={[styles.metaBadgeText, { color: urgCfg.color }]}>{urgCfg.label}</Text>
              </View>
              <View style={[styles.metaBadge, { backgroundColor: cfg.bg, borderColor: cfg.border, flex: 1 }]}>
                <MaterialIcons name="lightbulb" size={14} color={cfg.text} />
                <Text style={[styles.metaBadgeText, { color: cfg.text, flexShrink: 1 }]} numberOfLines={1}>
                  {result.suggestedAction}
                </Text>
              </View>
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <MaterialIcons name="analytics" size={16} color="#2563EB" />
                <Text style={styles.cardTitle}>Why this classification?</Text>
              </View>
              {result.indicators.map((ind, i) => (
                <View key={i} style={styles.indicatorRow}>
                  <View style={[styles.indicatorDot, { backgroundColor: cfg.text }]} />
                  <Text style={styles.indicatorText}>{ind}</Text>
                </View>
              ))}
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <MaterialIcons name="edit" size={16} color="#2563EB" />
                <Text style={styles.cardTitle}>AI-Generated Replies</Text>
              </View>

              <View style={styles.replyTabRow}>
                {(["short", "detailed"] as const).map((tab) => (
                  <TouchableOpacity
                    key={tab}
                    style={[styles.replyTab, activeReplyTab === tab && styles.replyTabActive]}
                    onPress={() => { setActiveReplyTab(tab); Haptics.selectionAsync(); }}
                    activeOpacity={0.8}
                  >
                    <MaterialIcons
                      name={tab === "short" ? "short-text" : "subject"}
                      size={14}
                      color={activeReplyTab === tab ? "#2563EB" : "#94a3b8"}
                    />
                    <Text style={[styles.replyTabText, activeReplyTab === tab && styles.replyTabTextActive]}>
                      {tab === "short" ? "Short Reply" : "Detailed Reply"}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {activeReplyTab === "short" && (
                <View>
                  <Text style={styles.replyLengthHint}>2–3 sentences · Direct & professional</Text>
                  <View style={styles.replyBox}>
                    <Text style={styles.replyText}>{result.shortReply}</Text>
                  </View>
                  <TouchableOpacity
                    style={[styles.copyBtn, copiedShort && styles.copyBtnSuccess]}
                    onPress={() => handleCopy(result.shortReply, "short")}
                    activeOpacity={0.8}
                  >
                    <MaterialIcons
                      name={copiedShort ? "check" : "content-copy"}
                      size={16}
                      color={copiedShort ? "#16a34a" : "#2563EB"}
                    />
                    <Text style={[styles.copyBtnText, copiedShort && { color: "#16a34a" }]}>
                      {copiedShort ? "Copied!" : "Copy Short Reply"}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

              {activeReplyTab === "detailed" && (
                <View>
                  <Text style={styles.replyLengthHint}>3 paragraphs · Context-aware & thorough</Text>
                  <View style={styles.replyBox}>
                    <Text style={styles.replyText}>{result.detailedReply}</Text>
                  </View>
                  <TouchableOpacity
                    style={[styles.copyBtn, copiedDetailed && styles.copyBtnSuccess]}
                    onPress={() => handleCopy(result.detailedReply, "detailed")}
                    activeOpacity={0.8}
                  >
                    <MaterialIcons
                      name={copiedDetailed ? "check" : "content-copy"}
                      size={16}
                      color={copiedDetailed ? "#16a34a" : "#2563EB"}
                    />
                    <Text style={[styles.copyBtnText, copiedDetailed && { color: "#16a34a" }]}>
                      {copiedDetailed ? "Copied!" : "Copy Detailed Reply"}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>

            <TouchableOpacity style={styles.analyzeAnotherBtn} onPress={handleClear} activeOpacity={0.8}>
              <MaterialIcons name="refresh" size={18} color="#2563EB" />
              <Text style={styles.analyzeAnotherText}>Analyze Another Message</Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f8fafc" },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f1f5f9", alignItems: "center", justifyContent: "center",
  },
  topBarCenter: { alignItems: "center" },
  topBarTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: "#0f172a" },
  aiBadge: {
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: "#f3e8ff", borderRadius: 20,
    paddingHorizontal: 7, paddingVertical: 2, marginTop: 2,
  },
  aiBadgeText: { fontSize: 9, fontFamily: "Inter_600SemiBold", color: "#7c3aed" },
  clearBtn: {
    paddingHorizontal: 12, paddingVertical: 6,
    backgroundColor: "#fef2f2", borderRadius: 8, borderWidth: 1, borderColor: "#fecaca",
  },
  clearBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#dc2626" },
  scroll: { flex: 1 },
  inputCard: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
    padding: 16, marginBottom: 12,
  },
  inputCardHeader: {
    flexDirection: "row", alignItems: "center", gap: 8,
    marginBottom: 12,
  },
  inputCardTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#0f172a" },
  textArea: {
    backgroundColor: "#f8fafc", borderRadius: 12,
    borderWidth: 1, borderColor: "#e2e8f0",
    padding: 14, minHeight: 130,
    fontSize: 14, fontFamily: "Inter_400Regular", color: "#0f172a",
    lineHeight: 22,
  },
  charCount: {
    flexDirection: "row", justifyContent: "space-between",
    alignItems: "center", marginTop: 6, paddingHorizontal: 2,
  },
  charCountText: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8" },
  advancedToggle: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    marginTop: 12, paddingTop: 12,
    borderTopWidth: 1, borderTopColor: "#f1f5f9",
  },
  advancedToggleText: { fontSize: 13, fontFamily: "Inter_500Medium", color: "#64748b" },
  advancedFields: { gap: 8, marginTop: 10 },
  advancedInput: {
    backgroundColor: "#f8fafc", borderRadius: 10,
    borderWidth: 1, borderColor: "#e2e8f0",
    paddingHorizontal: 12, paddingVertical: 10,
    fontSize: 14, fontFamily: "Inter_400Regular", color: "#0f172a",
  },
  exampleRow: { marginBottom: 12 },
  exampleLabel: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#94a3b8", marginBottom: 8 },
  exampleChips: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  exampleChip: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20,
    backgroundColor: "#f1f5f9", borderWidth: 1, borderColor: "#e2e8f0",
  },
  exampleChipRed: { backgroundColor: "#fef2f2", borderColor: "#fecaca" },
  exampleChipGreen: { backgroundColor: "#f0fdf4", borderColor: "#bbf7d0" },
  exampleChipText: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#64748b" },
  analyzeBtn: { borderRadius: 14, overflow: "hidden", marginBottom: 20 },
  analyzeBtnDisabled: { opacity: 0.6 },
  analyzeBtnGrad: {
    height: 56, flexDirection: "row",
    alignItems: "center", justifyContent: "center", gap: 10,
  },
  analyzeBtnText: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#ffffff" },
  resultBanner: {
    borderRadius: 16, padding: 20, marginBottom: 12,
  },
  resultBannerTop: {
    flexDirection: "row", justifyContent: "space-between",
    alignItems: "center", marginBottom: 14,
  },
  resultBannerLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  resultSentimentLabel: { fontSize: 20, fontFamily: "Inter_700Bold", color: "#ffffff" },
  resultSentimentSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)", marginTop: 2 },
  confidenceCircle: {
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: 14, padding: 10, alignItems: "center",
    minWidth: 72,
  },
  confidenceNum: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#ffffff" },
  confidenceSub: { fontSize: 10, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)" },
  confidenceBarBg: {
    height: 5, backgroundColor: "rgba(255,255,255,0.3)",
    borderRadius: 3, overflow: "hidden",
  },
  confidenceBarFill: { height: "100%", backgroundColor: "#ffffff", borderRadius: 3 },
  metaRow: { flexDirection: "row", gap: 10, marginBottom: 12 },
  metaBadge: {
    flexDirection: "row", alignItems: "center", gap: 5,
    borderRadius: 10, padding: 10, borderWidth: 1,
  },
  metaBadgeText: { fontSize: 12, fontFamily: "Inter_600SemiBold", flexShrink: 1 },
  card: {
    backgroundColor: "#ffffff", borderRadius: 16,
    borderWidth: 1, borderColor: "#e2e8f0",
    padding: 16, marginBottom: 12,
  },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  cardTitle: { fontSize: 14, fontFamily: "Inter_700Bold", color: "#0f172a" },
  indicatorRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 8 },
  indicatorDot: { width: 6, height: 6, borderRadius: 3, marginTop: 7, flexShrink: 0 },
  indicatorText: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 20 },
  replyTabRow: {
    flexDirection: "row", gap: 8, marginBottom: 12,
    backgroundColor: "#f1f5f9", borderRadius: 10, padding: 3,
  },
  replyTab: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 5, paddingVertical: 8, borderRadius: 8,
  },
  replyTabActive: { backgroundColor: "#ffffff" },
  replyTabText: { fontSize: 12, fontFamily: "Inter_500Medium", color: "#94a3b8" },
  replyTabTextActive: { color: "#2563EB", fontFamily: "Inter_600SemiBold" },
  replyLengthHint: {
    fontSize: 11, fontFamily: "Inter_400Regular", color: "#94a3b8",
    marginBottom: 8, fontStyle: "italic",
  },
  replyBox: {
    backgroundColor: "#f8fafc", borderRadius: 12,
    borderWidth: 1, borderColor: "#e2e8f0",
    padding: 14, marginBottom: 10,
  },
  replyText: { fontSize: 14, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 22 },
  copyBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 7, height: 42, borderRadius: 10,
    backgroundColor: "#eff6ff", borderWidth: 1, borderColor: "#bfdbfe",
  },
  copyBtnSuccess: { backgroundColor: "#f0fdf4", borderColor: "#bbf7d0" },
  copyBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#2563EB" },
  analyzeAnotherBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 48, borderRadius: 12,
    backgroundColor: "#ffffff", borderWidth: 1, borderColor: "#e2e8f0",
  },
  analyzeAnotherText: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#2563EB" },
});
