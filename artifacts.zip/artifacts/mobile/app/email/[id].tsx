import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useAppContext } from "@/context/AppContext";
import { SentimentBadge } from "@/components/SentimentBadge";

export default function EmailDetailScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { emails } = useAppContext();

  const email = emails.find((e) => e.id === id);

  const bottomPadding = Platform.OS === "web" ? 34 : insets.bottom + 24;

  if (!email) {
    return (
      <View style={styles.notFound}>
        <Feather name="alert-circle" size={40} color="#94a3b8" />
        <Text style={styles.notFoundText}>Email not found</Text>
      </View>
    );
  }

  const sentimentConfig = {
    positive: {
      gradient: ["#16a34a", "#15803d"] as [string, string],
      bg: "#f0fdf4",
      border: "#bbf7d0",
      text: "#15803d",
      headline: "Positive Client Sentiment Detected",
      icon: "thumbs-up" as const,
    },
    neutral: {
      gradient: ["#d97706", "#b45309"] as [string, string],
      bg: "#fffbeb",
      border: "#fde68a",
      text: "#b45309",
      headline: "Neutral Client Sentiment",
      icon: "minus-circle" as const,
    },
    negative: {
      gradient: ["#dc2626", "#b91c1c"] as [string, string],
      bg: "#fef2f2",
      border: "#fecaca",
      text: "#b91c1c",
      headline: "Attention Required: Negative Sentiment Detected",
      icon: "alert-triangle" as const,
    },
  };

  const cfg = sentimentConfig[email.sentiment];

  const TONES = [
    { label: "Professional", icon: "briefcase" as const },
    { label: "Friendly", icon: "smile" as const },
    { label: "Apologetic", icon: "heart" as const },
    { label: "Confident", icon: "zap" as const },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: bottomPadding }}
      showsVerticalScrollIndicator={false}
    >
      <LinearGradient colors={cfg.gradient} style={styles.sentimentBanner}>
        <View style={styles.bannerIcon}>
          <Feather name={cfg.icon} size={24} color="#ffffff" />
        </View>
        <Text style={styles.bannerHeadline}>{cfg.headline}</Text>
        <View style={styles.confidenceRow}>
          <Text style={styles.confidenceLabel}>Confidence Score:</Text>
          <Text style={styles.confidenceValue}>{email.confidence}%</Text>
        </View>
        <View style={styles.confidenceBar}>
          <View style={[styles.confidenceFill, { width: `${email.confidence}%` as any }]} />
        </View>
      </LinearGradient>

      <View style={styles.emailMeta}>
        <View style={styles.metaRow}>
          <Text style={styles.metaKey}>From</Text>
          <Text style={styles.metaVal}>{email.sender}</Text>
        </View>
        <View style={styles.metaDivider} />
        <View style={styles.metaRow}>
          <Text style={styles.metaKey}>Subject</Text>
          <Text style={styles.metaVal}>{email.subject}</Text>
        </View>
        <View style={styles.metaDivider} />
        <View style={styles.metaRow}>
          <Text style={styles.metaKey}>Time</Text>
          <Text style={styles.metaVal}>{email.time}</Text>
        </View>
        <View style={styles.metaDivider} />
        <View style={styles.metaRow}>
          <Text style={styles.metaKey}>Provider</Text>
          <View style={styles.providerTag}>
            <Feather name="mail" size={11} color="#64748b" />
            <Text style={styles.providerTagText}>{email.provider}</Text>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Message</Text>
        <View style={styles.emailBody}>
          <Text style={styles.emailBodyText}>{email.body}</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Sentiment Analysis</Text>
        <View style={[styles.analysisCard, { backgroundColor: cfg.bg, borderColor: cfg.border }]}>
          <View style={styles.analysisRow}>
            <Feather name="activity" size={16} color={cfg.text} />
            <Text style={[styles.analysisTitle, { color: cfg.text }]}>Key Indicators</Text>
          </View>
          {email.indicators.map((ind, i) => (
            <View key={i} style={styles.indicatorRow}>
              <View style={[styles.indicatorDot, { backgroundColor: cfg.text }]} />
              <Text style={styles.indicatorText}>{ind}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Suggested Response Tone</Text>
        <View style={styles.tonesRow}>
          {TONES.map((tone) => (
            <TouchableOpacity
              key={tone.label}
              style={styles.toneChip}
              activeOpacity={0.7}
              onPress={() => Haptics.selectionAsync()}
            >
              <Feather name={tone.icon} size={14} color="#2563EB" />
              <Text style={styles.toneChipText}>{tone.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={[styles.section, styles.actionSection]}>
        <TouchableOpacity
          style={styles.primaryBtn}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            router.push(`/reply/${email.id}`);
          }}
          activeOpacity={0.85}
        >
          <LinearGradient colors={["#2563EB", "#1d4ed8"]} style={styles.primaryBtnGrad}>
            <Feather name="edit-3" size={18} color="#ffffff" />
            <Text style={styles.primaryBtnText}>Open AI Reply Assistant</Text>
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.secondaryBtn} activeOpacity={0.7}>
            <Feather name="archive" size={16} color="#64748b" />
            <Text style={styles.secondaryBtnText}>Archive</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.secondaryBtn, styles.flagBtn]} activeOpacity={0.7}>
            <Feather name="flag" size={16} color="#dc2626" />
            <Text style={[styles.secondaryBtnText, { color: "#dc2626" }]}>Flag</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8fafc" },
  notFound: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  notFoundText: { fontSize: 16, color: "#94a3b8", fontFamily: "Inter_400Regular" },
  sentimentBanner: { padding: 20, alignItems: "center" },
  bannerIcon: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center", justifyContent: "center", marginBottom: 12,
  },
  bannerHeadline: {
    fontSize: 16, fontFamily: "Inter_700Bold", color: "#ffffff",
    textAlign: "center", marginBottom: 14,
  },
  confidenceRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 },
  confidenceLabel: { fontSize: 13, color: "rgba(255,255,255,0.8)", fontFamily: "Inter_400Regular" },
  confidenceValue: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#ffffff" },
  confidenceBar: {
    width: "80%", height: 6, backgroundColor: "rgba(255,255,255,0.3)",
    borderRadius: 3, overflow: "hidden",
  },
  confidenceFill: { height: "100%", backgroundColor: "#ffffff", borderRadius: 3 },
  emailMeta: {
    backgroundColor: "#ffffff", marginHorizontal: 16, marginTop: 16,
    borderRadius: 16, borderWidth: 1, borderColor: "#e2e8f0", overflow: "hidden",
  },
  metaRow: { flexDirection: "row", alignItems: "center", padding: 12, gap: 12 },
  metaKey: { width: 64, fontSize: 12, fontFamily: "Inter_500Medium", color: "#94a3b8", textTransform: "uppercase", letterSpacing: 0.5 },
  metaVal: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", color: "#0f172a" },
  metaDivider: { height: 1, backgroundColor: "#f1f5f9", marginHorizontal: 12 },
  providerTag: { flexDirection: "row", alignItems: "center", gap: 4 },
  providerTagText: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#64748b" },
  section: { paddingHorizontal: 16, marginTop: 16 },
  sectionLabel: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#64748b", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 },
  emailBody: {
    backgroundColor: "#ffffff", borderRadius: 16,
    padding: 16, borderWidth: 1, borderColor: "#e2e8f0",
  },
  emailBodyText: { fontSize: 14, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 22 },
  analysisCard: { borderRadius: 16, padding: 16, borderWidth: 1 },
  analysisRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  analysisTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  indicatorRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 6 },
  indicatorDot: { width: 6, height: 6, borderRadius: 3, marginTop: 7 },
  indicatorText: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular", color: "#374151", lineHeight: 20 },
  tonesRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  toneChip: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "#eff6ff", borderRadius: 20,
    paddingHorizontal: 14, paddingVertical: 8,
    borderWidth: 1, borderColor: "#bfdbfe",
  },
  toneChipText: { fontSize: 13, fontFamily: "Inter_500Medium", color: "#2563EB" },
  actionSection: { marginBottom: 12 },
  primaryBtn: { borderRadius: 14, overflow: "hidden", marginBottom: 12 },
  primaryBtnGrad: {
    height: 54, flexDirection: "row",
    alignItems: "center", justifyContent: "center", gap: 10,
  },
  primaryBtnText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#ffffff" },
  actionRow: { flexDirection: "row", gap: 12 },
  secondaryBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, height: 48, borderRadius: 12,
    backgroundColor: "#ffffff", borderWidth: 1, borderColor: "#e2e8f0",
  },
  flagBtn: { borderColor: "#fecaca", backgroundColor: "#fef2f2" },
  secondaryBtnText: { fontSize: 14, fontFamily: "Inter_500Medium", color: "#64748b" },
});
