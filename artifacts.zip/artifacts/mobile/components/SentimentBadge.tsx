import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";

type Sentiment = "positive" | "neutral" | "negative";

interface Props {
  sentiment: Sentiment;
  confidence?: number;
  compact?: boolean;
}

const CONFIG = {
  positive: {
    label: "Positive",
    color: "#16a34a",
    bg: "#f0fdf4",
    border: "#bbf7d0",
    icon: "thumbs-up" as const,
  },
  neutral: {
    label: "Neutral",
    color: "#d97706",
    bg: "#fffbeb",
    border: "#fde68a",
    icon: "minus" as const,
  },
  negative: {
    label: "Negative",
    color: "#dc2626",
    bg: "#fef2f2",
    border: "#fecaca",
    icon: "alert-circle" as const,
  },
};

export function SentimentBadge({ sentiment, confidence, compact }: Props) {
  const cfg = CONFIG[sentiment];

  if (compact) {
    return (
      <View style={[styles.compact, { backgroundColor: cfg.bg, borderColor: cfg.border }]}>
        <View style={[styles.dot, { backgroundColor: cfg.color }]} />
      </View>
    );
  }

  return (
    <View style={[styles.badge, { backgroundColor: cfg.bg, borderColor: cfg.border }]}>
      <Feather name={cfg.icon} size={12} color={cfg.color} />
      <Text style={[styles.badgeText, { color: cfg.color }]}>{cfg.label}</Text>
      {confidence !== undefined && (
        <Text style={[styles.confidence, { color: cfg.color }]}>{confidence}%</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
  },
  badgeText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  confidence: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    opacity: 0.8,
  },
  compact: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
});
