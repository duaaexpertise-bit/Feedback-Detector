import React from "react";
import { View, StyleSheet } from "react-native";
import Svg, { Circle } from "react-native-svg";

interface Props {
  positive: number;
  neutral: number;
  negative: number;
}

export function MiniPieChart({ positive, neutral, negative }: Props) {
  const total = positive + neutral + negative || 1;
  const size = 80;
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const cx = size / 2;
  const cy = size / 2;

  const posRatio = positive / total;
  const neuRatio = neutral / total;
  const negRatio = negative / total;

  const posDash = posRatio * circumference;
  const neuDash = neuRatio * circumference;
  const negDash = negRatio * circumference;

  const posOffset = 0;
  const neuOffset = -(posDash);
  const negOffset = -(posDash + neuDash);

  return (
    <View style={styles.container}>
      <Svg width={size} height={size}>
        <Circle cx={cx} cy={cy} r={radius} stroke="#f1f5f9" strokeWidth={strokeWidth} fill="none" />
        {positive > 0 && (
          <Circle
            cx={cx} cy={cy} r={radius}
            stroke="#16a34a"
            strokeWidth={strokeWidth}
            fill="none"
            strokeDasharray={`${posDash} ${circumference - posDash}`}
            strokeDashoffset={circumference * 0.25}
            strokeLinecap="round"
          />
        )}
        {neutral > 0 && (
          <Circle
            cx={cx} cy={cy} r={radius}
            stroke="#fbbf24"
            strokeWidth={strokeWidth}
            fill="none"
            strokeDasharray={`${neuDash} ${circumference - neuDash}`}
            strokeDashoffset={circumference * 0.25 + neuOffset}
            strokeLinecap="round"
          />
        )}
        {negative > 0 && (
          <Circle
            cx={cx} cy={cy} r={radius}
            stroke="#f87171"
            strokeWidth={strokeWidth}
            fill="none"
            strokeDasharray={`${negDash} ${circumference - negDash}`}
            strokeDashoffset={circumference * 0.25 + negOffset}
            strokeLinecap="round"
          />
        )}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    width: 80,
    height: 80,
  },
});
