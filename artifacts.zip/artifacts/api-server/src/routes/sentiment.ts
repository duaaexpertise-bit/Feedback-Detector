import { Router } from "express";
import OpenAI from "openai";

const router = Router();

const openai = new OpenAI({
  apiKey: process.env["OPENAI_API_KEY"],
});

router.post("/analyze", async (req, res) => {
  const { subject, body, sender } = req.body as {
    subject?: string;
    body?: string;
    sender?: string;
  };

  if (!body) {
    res.status(400).json({ error: "Email body is required" });
    return;
  }

  try {
    const prompt = `Analyze the sentiment of this client email and respond with JSON only.

From: ${sender || "Unknown"}
Subject: ${subject || "No subject"}
Body: ${body}

Respond with exactly this JSON structure:
{
  "sentiment": "positive" | "neutral" | "negative",
  "confidence": number (0-100),
  "indicators": ["string", "string", "string", "string"]
}

Rules:
- sentiment: positive = happy/approving/thankful, negative = angry/complaining/threatening, neutral = informational/questions
- confidence: how confident you are (70-99)
- indicators: 4 specific phrases or patterns that explain why you chose that sentiment`;

    const response = await openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 300,
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.choices[0]?.message?.content ?? "{}";
    const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const result = JSON.parse(cleaned) as {
      sentiment: "positive" | "neutral" | "negative";
      confidence: number;
      indicators: string[];
    };

    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Sentiment analysis failed");
    res.status(500).json({ error: "Analysis failed" });
  }
});

router.post("/reply", async (req, res) => {
  const { emailSubject, emailBody, senderName, sentiment, tone, length } = req.body as {
    emailSubject?: string;
    emailBody?: string;
    senderName?: string;
    sentiment?: string;
    tone?: string;
    length?: string;
  };

  if (!emailBody) {
    res.status(400).json({ error: "Email body is required" });
    return;
  }

  try {
    const toneDescriptions: Record<string, string> = {
      professional: "formal, business-appropriate, and polished",
      friendly: "warm, approachable, and conversational",
      apologetic: "empathetic, understanding, and sincerely apologetic",
      sales: "persuasive, opportunity-focused, and enthusiastic",
      confident: "direct, authoritative, and solution-oriented",
    };

    const isShort = (length ?? "short") === "short";

    const prompt = isShort
      ? `Write a SHORT email reply. STRICT RULE: Maximum 2-3 sentences only. Do NOT write paragraphs. Do NOT include a long greeting paragraph. Be direct and concise.

Tone: ${toneDescriptions[tone ?? "professional"] ?? "professional"}
Original email from ${senderName}: "${emailSubject}" — ${emailBody.slice(0, 300)}
Email sentiment: ${sentiment}

Output: 2-3 sentences maximum. Start with a brief greeting on the same line as the first sentence. End with a one-line sign-off.`
      : `Write a DETAILED email reply with 3 complete paragraphs.

Tone: ${toneDescriptions[tone ?? "professional"] ?? "professional"}
Original email from ${senderName}: "${emailSubject}"
Body: ${emailBody}
Email sentiment: ${sentiment}

Structure:
- Paragraph 1: Personalized greeting + acknowledge the email content specifically
- Paragraph 2: Address the main points in detail with context and explanation
- Paragraph 3: Next steps, offer further help, and a professional closing

Write a thorough, context-aware response. Include proper greeting (Dear/Hi ${senderName?.split(" ")[0] ?? "there"},) and sign-off. Do NOT write a short reply.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: isShort ? 120 : 500,
      messages: [{ role: "user", content: prompt }],
    });

    const reply = response.choices[0]?.message?.content ?? "";
    res.json({ reply });
  } catch (err) {
    req.log.error({ err }, "Reply generation failed");
    res.status(500).json({ error: "Reply generation failed" });
  }
});

router.post("/full", async (req, res) => {
  const { text, senderName, subject } = req.body as {
    text?: string;
    senderName?: string;
    subject?: string;
  };

  if (!text?.trim()) {
    res.status(400).json({ error: "Text is required" });
    return;
  }

  const firstName = (senderName ?? "").split(" ")[0] || "there";

  try {
    const analysisPromise = openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 350,
      messages: [
        {
          role: "user",
          content: `Analyze this client message and return JSON only. No markdown.

${subject ? `Subject: ${subject}` : ""}
${senderName ? `From: ${senderName}` : ""}
Message: ${text.slice(0, 500)}

Return exactly:
{
  "sentiment": "positive"|"neutral"|"negative",
  "confidence": number 70-99,
  "urgency": "low"|"medium"|"high",
  "indicators": ["phrase1","phrase2","phrase3","phrase4"],
  "suggestedAction": "one actionable sentence under 15 words"
}

Rules:
- urgency high = threats/refunds/angry, medium = complaints/concerns, low = positive/neutral
- indicators: 4 specific quoted phrases or patterns that explain the sentiment
- suggestedAction: concrete next step for the recipient`,
        },
      ],
    });

    const shortReplyPromise = openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 100,
      messages: [
        {
          role: "user",
          content: `Write a SHORT professional email reply. STRICT: 2-3 sentences ONLY. No extra paragraphs.

Message from ${senderName ?? "client"}: "${text.slice(0, 300)}"

Reply directly and professionally. Start with "Hi ${firstName}," on the same line as the first sentence. End with a one-line sign-off.`,
        },
      ],
    });

    const detailedReplyPromise = openai.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 450,
      messages: [
        {
          role: "user",
          content: `Write a DETAILED professional email reply with exactly 3 paragraphs.

Message from ${senderName ?? "client"}${subject ? ` re: ${subject}` : ""}: "${text.slice(0, 400)}"

Paragraph 1: Greeting ("Dear ${firstName},") + acknowledge the specific content of their message
Paragraph 2: Address the main points in full detail with context and explanation
Paragraph 3: Next steps + offer further help + professional sign-off ("Best regards,")

Write 3 complete paragraphs. Do NOT write a short reply.`,
        },
      ],
    });

    const [analysisRes, shortRes, detailedRes] = await Promise.all([
      analysisPromise,
      shortReplyPromise,
      detailedReplyPromise,
    ]);

    const analysisRaw = (analysisRes.choices[0]?.message?.content ?? "{}").replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const analysis = JSON.parse(analysisRaw) as {
      sentiment: "positive" | "neutral" | "negative";
      confidence: number;
      urgency: "low" | "medium" | "high";
      indicators: string[];
      suggestedAction: string;
    };

    res.json({
      sentiment: analysis.sentiment ?? "neutral",
      confidence: analysis.confidence ?? 75,
      urgency: analysis.urgency ?? "low",
      indicators: analysis.indicators ?? [],
      suggestedAction: analysis.suggestedAction ?? "Review and respond promptly.",
      shortReply: shortRes.choices[0]?.message?.content?.trim() ?? "",
      detailedReply: detailedRes.choices[0]?.message?.content?.trim() ?? "",
    });
  } catch (err) {
    req.log.error({ err }, "Full analysis failed");
    res.status(500).json({ error: "Analysis failed" });
  }
});

export default router;
